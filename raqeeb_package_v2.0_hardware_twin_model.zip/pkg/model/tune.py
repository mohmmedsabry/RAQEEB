"""Tuning on TRAIN/VAL only (never touches LOCKED_TEST). Picks thresholds quantiles + persistence rule."""
import sys, os, itertools, numpy as np, pandas as pd
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from raqeeb_model import RaqeebModel
D=pd.read_csv("data/data.csv"); tr,va=[D[D.split==s].reset_index(drop=True) for s in ("train","val")]
def episodes(al): return 0 if len(al)==0 else 1+int((np.diff(al)>1).sum())
def sess(d,flag,k,n):
    det,delay,fa,hrs=[],[],0,0.0
    for sid,g in d.assign(f=flag).groupby("session_id",sort=False):
        w=g.f.rolling(n,min_periods=n).sum().values; al=np.where(w>=k)[0]
        if g.fault_type.iloc[0]=="N": fa+=episodes(al); hrs+=len(g)*5/3600
        else: det.append(len(al)>0)
    return float(np.mean(det)),fa/hrs
rows=[]
for qu,qa in itertools.product((0.95,0.97,0.99),(0.995,0.999)):
    m=RaqeebModel(q_unc=qu,q_anom=qa).fit(tr,va); P=m.predict(va); z=P.zone.values; y=va.label_binary.values
    for src,flag in (("zone>=1",(z>=1).astype(int)),("zone==2",(z==2).astype(int))):
        rec=((flag==1)&(y==1)).sum()/(y==1).sum(); fpr=((flag==1)&(y==0)).sum()/(y==0).sum()
        for k,n in ((3,5),(4,5),(5,5),(2,3),(3,3)):
            dr,fah=sess(va,flag,k,n); rows.append(dict(q_unc=qu,q_anom=qa,series=src,rule=f"{k}of{n}",win_recall=round(rec,3),win_FPR=round(fpr,3),session_detect=round(dr,3),false_alarms_per_h=round(fah,2),
                      uncertain_share_normal=round(float(((z==1)&(y==0)).sum()/(y==0).sum()),3)))
R=pd.DataFrame(rows); R.to_csv("models/tuning_val.csv",index=False)
ok=R[(R.session_detect>=0.95)].sort_values(["false_alarms_per_h","win_FPR"]); print(ok.head(12).to_string(index=False))
