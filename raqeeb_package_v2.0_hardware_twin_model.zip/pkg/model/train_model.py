"""Train + evaluate. Threshold selection uses TRAIN/VAL only.  LOCKED TEST is evaluated ONCE:  python model/train_model.py --final
(refuses to run twice unless --force; result + file hash stored in models/test_evaluation.json)."""
import argparse, hashlib, json, os, sys, time
import numpy as np, pandas as pd
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from raqeeb_model import RaqeebModel, FEATS, VERSION
ap=argparse.ArgumentParser(); ap.add_argument("--final",action="store_true"); ap.add_argument("--force",action="store_true"); a=ap.parse_args()
D=pd.read_csv("data/data.csv"); tr,va,te=[D[D.split==s].reset_index(drop=True) for s in ("train","val","test")]
sha=lambda p:hashlib.sha256(open(p,"rb").read()).hexdigest()
def prf(y,p):
    tp=int(((p==1)&(y==1)).sum()); fp=int(((p==1)&(y==0)).sum()); fn=int(((p==0)&(y==1)).sum()); tn=int(((p==0)&(y==0)).sum())
    return dict(TP=tp,FP=fp,FN=fn,TN=tn,precision=round(tp/max(tp+fp,1),3),recall=round(tp/max(tp+fn,1),3),FPR=round(fp/max(fp+tn,1),3))
def alarms(zone_nonnormal,k=3,n=5):
    w=pd.Series(zone_nonnormal).rolling(n,min_periods=n).sum().values; return np.where(w>=k)[0]
def evaluate(model,d,name):
    P=model.predict(d); d=d.assign(zone=P.zone.values); y=d.label_binary.values; res={"windows":len(d),"split":name}
    res["flagged(uncertain+anomaly)"]=prf(y,(d.zone>=1).astype(int).values); res["auto_alert(anomaly only)"]=prf(y,(d.zone==2).astype(int).values)
    res["zone_share_normal_windows"]={int(z):round(float((d[d.label_binary==0].zone==z).mean()),3) for z in (0,1,2)}
    res["automation_rate_all_windows(not uncertain)"]=round(float((d.zone!=1).mean()),3)
    res["recall_flagged_by_fault"]={f:round(float((d[d.fault_type==f].zone>=1).mean()),3) for f in ("F1","F2","F3","F4")}
    res["recall_flagged_by_fault_severity"]={f"{f}-{s}":round(float((d[(d.fault_type==f)&(d.severity==s)].zone>=1).mean()),3) for f in ("F1","F2","F3","F4") for s in (1,2)}
    # session-level. AUTO-ALARM: zone==2 in >=3 of last 5 windows.  REVIEW-PERSIST: zone>=1 in 5 of last 5 windows (goes to review queue)
    def ep(al): return 0 if len(al)==0 else 1+int((np.diff(al)>1).sum())
    stats={"auto":{"det":[],"delay":[],"fa":0},"review":{"det":[],"delay":[],"fa":0}}; hrs=0.0
    for sid,g in d.groupby("session_id",sort=False):
        a_al=alarms((g.zone==2).values,3,5); r_al=alarms((g.zone>=1).values,5,5)
        if g.fault_type.iloc[0]=="N": stats["auto"]["fa"]+=ep(a_al); stats["review"]["fa"]+=ep(r_al); hrs+=len(g)*5/3600
        else:
            for key,al in (("auto",a_al),("review",r_al)): stats[key]["det"].append(len(al)>0); stats[key]["delay"].append(float(g.elapsed_min.iloc[al[0]]) if len(al) else np.nan)
    res["session_level"]={"normal_hours":round(hrs,2),"fault_sessions":len(stats["auto"]["det"])}
    for key,name in (("auto","auto_alarm(zone2 3of5)"),("review","review_persist(zone>=1 5of5)")):
        S=stats[key]; res["session_level"][name]={"detected":int(sum(S["det"])),"detection_rate":round(float(np.mean(S["det"])),3),"median_delay_min":round(float(np.nanmedian(S["delay"])),2),
                                                  "false_alarm_episodes_per_normal_hour":round(S["fa"]/max(hrs,1e-9),2)}
    res["_per_session_detection"]={sid:bool(len(alarms((g.zone>=1).values))>0) for sid,g in d[d.label_binary==1].groupby("session_id",sort=False)}
    return res
def baseline(tr,va,d):   # NO-AI baseline: per speed, max |z| of 3 channels vs normal train stats, threshold = 95th pct of val normal
    ch=["current_mean_mA","vib_rms_total","temp_delta_C"]; flag=np.zeros(len(d),int)
    for sp in d.pwm_duty.unique():
        t=tr[(tr.pwm_duty==sp)&(tr.label_binary==0)]; v=va[(va.pwm_duty==sp)&(va.label_binary==0)]; mu,sd=t[ch].mean(),t[ch].std()
        s=lambda x:((x[ch]-mu)/sd).abs().max(axis=1); thr=np.quantile(s(v),0.95); k=(d.pwm_duty==sp).values; flag[k]=(s(d[k])>thr).astype(int)
    return flag
t0=time.time(); model=RaqeebModel().fit(tr,va); os.makedirs("models",exist_ok=True)
rv=evaluate(model,va,"val"); bv=prf(va.label_binary.values,baseline(tr,va,va)); rv["no_AI_baseline_flagged"]=bv
json.dump(rv,open("models/metrics_val.json","w"),indent=1,ensure_ascii=False)
print("VALIDATION  flagged:",rv["flagged(uncertain+anomaly)"],"\n            auto-alert:",rv["auto_alert(anomaly only)"],"\n            by fault:",rv["recall_flagged_by_fault"],
      "\n            sessions:",rv["session_level"],"\n            baseline(no AI):",bv,"\n            automation rate:",rv["automation_rate_all_windows(not uncertain)"])
model.save("models/raqeeb_model_v1.0.joblib"); json.dump(model.info,open("models/model_info.json","w"),indent=1)
if a.final:
    lock="models/test_evaluation.json"
    if os.path.exists(lock) and not a.force: sys.exit("LOCKED TEST already evaluated ("+lock+"). Use --force only with supervisor approval.")
    rt=evaluate(model,te,"test"); bt=prf(te.label_binary.values,baseline(tr,va,te)); rt["no_AI_baseline_flagged"]=bt
    rt["locked_test_sha256"]=sha("splits/LOCKED_TEST/test_features.csv"); rt["train_sha256"]=sha("splits/train/train_features.csv"); rt["model_version"]=VERSION
    rt["evaluated_at"]=time.strftime("%Y-%m-%d %H:%M:%S"); json.dump(rt,open(lock,"w"),indent=1,ensure_ascii=False)
    print("\nLOCKED TEST flagged:",rt["flagged(uncertain+anomaly)"],"\n            auto-alert:",rt["auto_alert(anomaly only)"],"\n            by fault:",rt["recall_flagged_by_fault"],
      "\n            sessions:",rt["session_level"],"\n            baseline(no AI):",bt,"\n            automation rate:",rt["automation_rate_all_windows(not uncertain)"])
