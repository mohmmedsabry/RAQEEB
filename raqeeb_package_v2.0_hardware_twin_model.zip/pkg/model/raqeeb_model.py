"""RAQEEB anomaly model v1.0  = per-speed Isolation Forest + physics-based thermal check + 3 decision zones.
 zone 0 normal | 1 uncertain -> human review queue | 2 anomaly -> alert (still subject to orchestrator rules)
 The model NEVER outputs a diagnosis. It outputs: zone, scores, evidence (top deviating features). Fault names are not predicted."""
import numpy as np, pandas as pd, joblib
from scipy.optimize import curve_fit
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
VERSION="raqeeb-if-v1.0"
FEATS=["temp_delta_C","temp_slope_C_min","elapsed_min","rpm","current_mean_mA","current_std_mA","current_max_mA","bus_voltage_V","ax_rms","ay_rms","az_rms",
       "vib_rms_total","vib_peak","vib_p2p","vib_crest","vib_kurtosis","vib_skew","dom_freq_hz","spec_centroid_hz","band_0_50","band_50_150","band_150_250","band_250_500","amp_1x"]
# NOT used by the model: ids, labels, regime, load_state (unknown at runtime), fan_state is used only to pick the expected warm-up curve
def _warm(t,A,tau): return A*(1-np.exp(-t/tau))
class RaqeebModel:
    def __init__(self,q_unc=0.97,q_anom=0.999,n_estimators=300,seed=0): self.q_unc,self.q_anom,self.n,self.seed=q_unc,q_anom,n_estimators,seed
    def fit(self,train,val):
        tr=train[train.label_binary==0]; va=val[val.label_binary==0]; self.m={}; self.info={"version":VERSION,"features":FEATS,"q_unc":self.q_unc,"q_anom":self.q_anom}
        for sp in sorted(tr.pwm_duty.unique()):
            t=tr[tr.pwm_duty==sp]; v=va[va.pwm_duty==sp]; sc=StandardScaler().fit(t[FEATS]); iso=IsolationForest(n_estimators=self.n,random_state=self.seed).fit(sc.transform(t[FEATS]))
            curves={}
            for fan in (0,1):
                d=t[t.fan_state==fan]
                if len(d)>=60:
                    p,_=curve_fit(_warm,d.elapsed_min.values,d.temp_delta_C.values,p0=(10,5),bounds=([0,0.3],[60,60])); curves[fan]=p
            pa,_=curve_fit(_warm,t.elapsed_min.values,t.temp_delta_C.values,p0=(10,5),bounds=([0,0.3],[60,60])); curves["all"]=pa
            sig=float(np.std(np.concatenate([t[t.fan_state==f].temp_delta_C.values-_warm(t[t.fan_state==f].elapsed_min.values,*curves.get(f,pa)) for f in (0,1) if (t.fan_state==f).any()])))
            self.m[sp]=dict(sc=sc,iso=iso,curves=curves,sig=sig)
            s=self._if_score(sp,v); r=self._th_resid(sp,v)
            self.m[sp].update(t_unc=float(np.quantile(s,self.q_unc)),t_anom=float(np.quantile(s,self.q_anom)),r_unc=float(np.quantile(r,self.q_unc)),r_anom=float(np.quantile(r,self.q_anom)))
            self.info[f"speed_{sp}"]=dict(train_windows=len(t),val_normal_windows=len(v),fan_curves=sorted(map(str,curves)),**{k:round(self.m[sp][k],4) for k in("t_unc","t_anom","r_unc","r_anom","sig")})
        return self
    def _if_score(self,sp,d): M=self.m[sp]; return -M["iso"].score_samples(M["sc"].transform(d[FEATS]))
    def _th_resid(self,sp,d):
        M=self.m[sp]; out=np.zeros(len(d))
        for f in (0,1):
            k=(d.fan_state==f).values
            if k.any(): out[k]=(d.temp_delta_C.values[k]-_warm(d.elapsed_min.values[k],*M["curves"].get(f,M["curves"]["all"])))/M["sig"]
        return out
    def predict(self,df):
        out=pd.DataFrame(index=df.index); out["if_score"]=np.nan; out["thermal_resid"]=np.nan; out["zone"]=0; out["reason"]=""; out["top_deviations"]=None
        for sp in df.pwm_duty.unique():
            k=(df.pwm_duty==sp).values; d=df[k]
            if sp not in self.m: out.loc[k,"zone"]=1; out.loc[k,"reason"]="unknown_speed_setpoint -> review"; continue
            M=self.m[sp]; s=self._if_score(sp,d); r=self._th_resid(sp,d)
            z_if=np.where(s>M["t_anom"],2,np.where(s>M["t_unc"],1,0)); z_th=np.where(r>M["r_anom"],2,np.where(r>M["r_unc"],1,0)); z=np.maximum(z_if,z_th)
            Z=M["sc"].transform(d[FEATS]); top=[[{"feature":FEATS[j],"z":round(float(Z[i,j]),2)} for j in np.argsort(-np.abs(Z[i]))[:3]] for i in range(len(d))]
            reason=np.where((z_if>0)&(z_th>0),"ml_pattern+thermal_rise",np.where(z_th>0,"thermal_rise",np.where(z_if>0,"ml_pattern","")))
            out.loc[k,"if_score"]=s; out.loc[k,"thermal_resid"]=r; out.loc[k,"zone"]=z; out.loc[k,"reason"]=reason
            out.loc[k,"top_deviations"]=pd.Series(top,index=d.index).where(z>0,None)
        out["requires_human_review"]=(out.zone==1); out["model_version"]=VERSION; return out
    def save(self,path): joblib.dump(self,path)
    @staticmethod
    def load(path): return joblib.load(path)
