"""Generate models/model_card.md from models/*.json (numbers are never typed by hand)."""
import json
V=json.load(open("models/metrics_val.json")); T=json.load(open("models/test_evaluation.json")); I=json.load(open("models/model_info.json"))
f=lambda r:f"precision {r['precision']} / recall {r['recall']} / FPR {r['FPR']} (TP {r['TP']}, FP {r['FP']}, FN {r['FN']}, TN {r['TN']})"
def sess(R,k): s=R["session_level"][k]; return f"كشف {s['detected']}/{R['session_level']['fault_sessions']} جلسة عطل ({s['detection_rate']*100:.1f}%)، متوسط التأخير {s['median_delay_min']} د، إنذارات كاذبة {s['false_alarm_episodes_per_normal_hour']} لكل ساعة طبيعية"
card=f"""# Model Card – {I['version']} (رقيب) — مُدرَّب على داتا v2.0 (توليد عبر الـ digital twin)

> ⚠ **الأرقام على بيانات محاكاة (`source=simulated`).** تثبت أن الكود وخط المعالجة يعملان؛ **لا تُمثّل أداءً حقيقيًا** ولا تُحسب ضمن الـ 85% (NFR-001).

## 1) النموذج
- **النوع:** Isolation Forest **لكل سرعة (pwm 40/70/100)** يُدرَّب على الحالة الطبيعية فقط + فحص حراري مبني على منحنى تسخين متوقع (حسب السرعة وحالة المروحة) + 3 مناطق قرار.
- **المناطق:** `0` طبيعي — `1` غير مؤكد (review queue) — `2` شاذ (تنبيه). **لا يتنبأ باسم العطل ولا يؤكد تشخيصًا** (FR-015).
- **المخرجات:** zone، if_score، thermal_resid، reason، أعلى 3 انحرافات (evidence)، model_version.
- **الـ features ({len(I['features'])}):** {', '.join(I['features'])}
- **لا يستخدم:** المعرّفات، الـ labels، `regime`، `load_state` (الحمل غير معروف وقت التشغيل). `fan_state` يختار منحنى التسخين فقط.
- **الـ thresholds:** percentile {I['q_unc']} (غير مؤكد) و{I['q_anom']} (شاذ) من **validation الطبيعي** لكل سرعة (`models/model_info.json`). اختيار الإعدادات تم على الـ validation فقط بقاعدة: أعلى كشف للجلسات ≥95% ثم أقل إنذارات كاذبة.
- **قاعدة التنبيه:** منطقة 2 في 3 من آخر 5 نوافذ (ALERT). المنطقة ≥1 في 5 من 5 → REVIEW_REQUEST. **القرار النهائي بشري.**
- **السلوك الآمن:** سرعة غير معروفة → منطقة 1 (مراجعة). الحماية المحلية (قطع التيار/الحرارة) على الـ ESP32 ومستقلة عن الموديل (FR-022).

## 2) البيانات
- v2.0: كل نافذة تُنتَج من **إشارة خام على مستوى الأسلاك** (digital twin) وتمر على نفس مسار الهاردوير: `logger_pc.parse → extract_features`. تقسيم بالجلسة: train طبيعي (3 أيام)، val (يومان طبيعيان + أعطال تكرار 1،2)، test مقفول (يومان طبيعيان + أعطال تكرار 3).
- `train_sha256` = `{T['train_sha256'][:16]}…` | `locked_test_sha256` = `{T['locked_test_sha256'][:16]}…`
- **الـ test المقفول اتقيّم مرة واحدة** ({T['evaluated_at']}) على هذه النسخة من الداتا؛ لم يُعدَّل شيء بعده. (نتائج v1.2 مؤرشفة في `archive_models_v1.2/`.)

## 3) الأداء
| | Validation | **LOCKED TEST** |
|---|---|---|
| تنبيه أو غير مؤكد (zone≥1) | {f(V['flagged(uncertain+anomaly)'])} | {f(T['flagged(uncertain+anomaly)'])} |
| تنبيه فقط (zone 2) | {f(V['auto_alert(anomaly only)'])} | {f(T['auto_alert(anomaly only)'])} |
| Baseline بدون AI (عتبات لكل سرعة) | {f(V['no_AI_baseline_flagged'])} | {f(T['no_AI_baseline_flagged'])} |
| معدل الأتمتة (ليس غير مؤكد) | {V['automation_rate_all_windows(not uncertain)']} | {T['automation_rate_all_windows(not uncertain)']} |

**كشف النوافذ حسب العطل (zone≥1):** val {V['recall_flagged_by_fault']} | test {T['recall_flagged_by_fault']}

**على مستوى الجلسة (test):**
- ALERT (zone 2 في 3 من 5): {sess(T,'auto_alarm(zone2 3of5)')}
- REVIEW (zone≥1 في 5 من 5): {sess(T,'review_persist(zone>=1 5of5)')}

## 4) نقاط ضعف معروفة
1. **فجوة val ← test:** FPR (zone≥1) ارتفع من {V['flagged(uncertain+anomaly)']['FPR']} إلى {T['flagged(uncertain+anomaly)']['FPR']}. أيام الـ test الطبيعية تختلف في الحرارة/التركيب عن أيام الـ val؛ والـ thresholds مبنية على يومين فقط.
2. **F3 وF4 هما الأضعف** (test: {T['recall_flagged_by_fault']['F3']} و{T['recall_flagged_by_fault']['F4']}).
3. **الـ baseline بدون AI قريب في الـ recall** (val {V['no_AI_baseline_flagged']['recall']} مقابل {V['flagged(uncertain+anomaly)']['recall']}) لأن تأثير الأعطال في المحاكاة كبير على القنوات الثلاث؛ الفرق الواضح في الـ test هو الإنذارات الكاذبة ({T['flagged(uncertain+anomaly)']['FPR']} مقابل {T['no_AI_baseline_flagged']['FPR']}). لا تستنتجوا تفوقًا حقيقيًا قبل بيانات الجهاز.
4. **المحاكاة من كتابتي** بثوابت مفترضة (سرعات، نبضات الـ encoder، تيار، ثوابت حرارية).
5. **بدء التشغيل البارد:** في عرض الـ bridge ظهر REVIEW_REQUEST واحد خاطئ في أول دقيقة من جلسة (فرق حرارة البداية عن المنحنى المتوقع).
6. **مؤشر إغلاق Workflow 3 للعطل F2** (kurtosis) غير رتيب مع الشدة: طابقت القاعدة 11 من 12 حالة.

## 5) الاستخدام والقيود
- **المقصود:** كشف انحراف عن السلوك الطبيعي لمحرك DC صغير على bench، وإحالة غير المؤكد لإنسان.
- **غير مقصود:** تشخيص أعطال محددة، قرارات سلامة، محركات أو سرعات أخرى بدون إعادة تدريب، أو اعتبار الأرقام أداءً حقيقيًا.

## 6) إعادة الإنتاج
```
python simulator/build_from_twin.py                    # توليد الداتا v2.0
python tools/validate_data.py data/data.csv            # PASS قبل أي تدريب
python model/tune.py                                   # ضبط على train/val فقط
python model/train_model.py --final                    # تدريب + تقييم الـ test مرة واحدة (يرفض التكرار)
python model/make_model_card.py                        # توليد هذا الملف من JSON
```
## 7) عند توفر بيانات حقيقية
أعيدوا التدريب بنفس الكود على تسجيلات الـ GA25 (أيام طبيعية أكثر مع `load_state`)، وقيّموا على test حقيقي جديد مقفول، وراجعوا الـ model card.
"""
open("models/model_card.md","w").write(card); print("model_card.md written")
