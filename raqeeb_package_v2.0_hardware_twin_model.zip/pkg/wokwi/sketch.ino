// RAQEEB bench logger - ONE firmware for Wokwi (SIM_WOKWI=1) and real hardware (SIM_WOKWI=0).
// DRAFT: written without access to Wokwi or hardware. Syntax-checked only. Verify every TODO constant before powering a real motor.
// Protocol per window (same as tools/logger_pc.py + runtime/bridge.py expect):
//   #WIN,<ms>,<pwm>,<fan>,<enc_pulses>,<motor_temp_C>,<ambient_C>,<N>   then N lines  r,<ax>,<ay>,<az>,<shunt_raw|-1>,<bus_raw|-1>   then  #END
//   '#TRIP,<reason>' when local protection cuts the motor.   Commands on Serial:  P<0-100> speed, F<0|1> fan, R reset trip.
#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#define SIM_WOKWI 1            // 1 = synthetic vibration/current from potentiometers (Wokwi) ; 0 = real MPU6050 + INA219 + encoder
// ---- pins (see docs/HARDWARE_WIRING_AR.md) ----
const int PIN_ENA=25, PIN_IN1=26, PIN_IN2=27, PIN_FAN=14, PIN_ENC_A=34, PIN_ENC_B=35, PIN_ONEWIRE=4, PIN_BTN=13;
const int PIN_POT_SPEED=36, PIN_POT_FAULT=32, PIN_POT_SEV=33;      // Wokwi only
// ---- TODO: real values from GA25/driver datasheets and baseline runs (0 = protection disabled) ----
const float I_MAX_MA = 0;      // TODO trip current
const float T_MAX_C  = 0;      // TODO trip temperature
const float ENC_PPR_SIM = 1000;  // ASSUMED (sim only)
const int   WINDOW_N = 2000;   // 2 s at 1 kHz
const uint8_t MPU=0x68, INA=0x40;
OneWire ow(PIN_ONEWIRE); DallasTemperature ds(&ow);
volatile uint32_t pulses=0; void IRAM_ATTR isrEnc(){ pulses++; }
int pwmDuty=70, fanOn=1; float lastTemp=25, lastAmb=25; bool tripped=false;
static int16_t buf[WINDOW_N][5];
void wr8(uint8_t a,uint8_t r,uint8_t v){Wire.beginTransmission(a);Wire.write(r);Wire.write(v);Wire.endTransmission();}
int16_t rd16(uint8_t a,uint8_t r){Wire.beginTransmission(a);Wire.write(r);Wire.endTransmission(false);Wire.requestFrom(a,(uint8_t)2);return (Wire.read()<<8)|Wire.read();}
void setMotor(int duty){ pwmDuty=constrain(duty,0,100); digitalWrite(PIN_IN1,pwmDuty>0); digitalWrite(PIN_IN2,LOW); ledcWrite(PIN_ENA,map(pwmDuty,0,100,0,255)); }
void trip(const char* why){ setMotor(0); tripped=true; Serial.printf("#TRIP,%s\n",why); }
#if SIM_WOKWI
// ---------- synthetic physics (same constants as simulator/twin.py; ASSUMED values) ----------
float gauss(){ static bool have=false; static float g2=0; if(have){have=false;return g2;} float u1=random(1,10000)/10000.0f,u2=random(0,10000)/10000.0f; float r=sqrtf(-2.0f*logf(u1)); g2=r*sinf(6.2831853f*u2); have=true; return r*cosf(6.2831853f*u2); }
float simT=0; unsigned long simMs=0; int simFault=0, simSev=1; float simRpm=0;
int speedFromPot(){ int v=analogRead(PIN_POT_SPEED); return v<1365?40:(v<2730?70:100); }
void simControls(){ pwmDuty=speedFromPot(); int fv=analogRead(PIN_POT_FAULT); simFault=constrain(fv/820,0,4);   // 0 N,1 F1,2 F2,3 F3,4 F4
  simSev=analogRead(PIN_POT_SEV)>2048?2:1; if(simFault==4) fanOn=0; }
void simWindow(){
  float rpm0 = pwmDuty==40?120:(pwmDuty==70?220:320); int s=simSev; int f=simFault;
  simRpm = rpm0*(f==3? 1-0.055f*s : 1.0f) + gauss()*1.2f; float f1=simRpm/60.0f, mesh=15.0f*f1;
  float a1=fabsf(0.004f+0.0005f*gauss())*(rpm0/200.0f); if(f==1) a1+=0.009f*s*(rpm0/200.0f)*(rpm0/200.0f);
  float sigb=(0.012f+0.00005f*rpm0)*(1.0f+(f==2?0.14f*s:0)+(f==3?0.07f*s:0));
  float ph[3]={random(0,628)/100.0f,random(0,628)/100.0f,random(0,628)/100.0f}, kx[3]={1.0f,0.6f,0.8f}, off[3]={0.02f,-0.01f,1.0f};
  for(int i=0;i<WINDOW_N;i++){ float t=i/1000.0f;
    for(int k=0;k<3;k++){ float v=a1*sinf(6.2831853f*f1*t+ph[k])+0.012f*(rpm0/200.0f)*sinf(6.2831853f*mesh*t+1.7f*ph[k])+0.6f*sigb*gauss();
      if(f==3) v+=0.004f*s*sinf(12.566371f*f1*t+ph[k]);
      v=kx[k]*v+0.0065f*gauss()+off[k]; buf[i][k]=(int16_t)lroundf(v*8192.0f); }
    buf[i][3]=-1; buf[i][4]=-1; }
  if(f==2){ int n=25*s; for(int j=0;j<n;j++){ int p=random(0,WINDOW_N-40); float amp=(random(0,2)?1:-1)*(0.08f+random(0,100)/1000.0f)*s;
      for(int m=0;m<40;m++){ float r=amp*expf(-m/8.0f)*sinf(6.2831853f*180.0f*m/1000.0f); buf[p+m][0]+=(int16_t)lroundf(r*8192.0f); buf[p+m][1]+=(int16_t)lroundf(0.7f*r*8192.0f); buf[p+m][2]+=(int16_t)lroundf(0.8f*r*8192.0f);} } }
  float imean=(120.0f+0.9f*rpm0)*(f==3?1+0.33f*s:1.0f), istd=18.0f*(f==3?1+0.7f*s:1.0f); float ic=imean*(1+0.015f*gauss());
  for(int i=0;i<WINDOW_N;i+=5){ float cur=ic+istd*gauss(); buf[i][3]=(int16_t)lroundf(cur*10.0f); buf[i][4]=(int16_t)lroundf((11.85f-0.0012f*cur)/0.004f); }
  float amb=lastAmb; float tss=amb+5.0f+0.022f*rpm0-(fanOn?4.0f:0.0f)+(f==4?7.0f*s:0.0f), tau=(f==4)?600.0f:420.0f;
  if(simT==0) simT=amb+2.0f; simT+=(tss-simT)*(1.0f-expf(-5.0f/tau)); simMs+=5000;
  pulses=(uint32_t)lroundf(simRpm/60.0f*2.0f*ENC_PPR_SIM);
}
#endif
void setup(){
  Serial.begin(921600); Wire.begin(21,22); Wire.setClock(400000);
  pinMode(PIN_IN1,OUTPUT); pinMode(PIN_IN2,OUTPUT); pinMode(PIN_FAN,OUTPUT); pinMode(PIN_ENC_A,INPUT); pinMode(PIN_ENC_B,INPUT); pinMode(PIN_BTN,INPUT_PULLUP);
  ledcAttach(PIN_ENA,20000,8);                         // arduino-esp32 v3 API (v2: ledcSetup + ledcAttachPin)
  attachInterrupt(PIN_ENC_A,isrEnc,RISING);
  wr8(MPU,0x6B,0x00); wr8(MPU,0x1A,0x00); wr8(MPU,0x19,0x07); wr8(MPU,0x1C,0x08);   // wake, DLPF off, 8k/(1+7)=1 kHz, +-4 g
  ds.begin(); ds.setWaitForConversion(false); ds.requestTemperatures();
  setMotor(pwmDuty); digitalWrite(PIN_FAN,fanOn);
  Serial.println("#SESSION,wokwi_or_bench");
}
void loop(){
  while(Serial.available()){ char c=Serial.read(); if(c=='P'){ int d=Serial.parseInt(); if(!tripped) setMotor(d);} if(c=='F'){ fanOn=Serial.parseInt(); digitalWrite(PIN_FAN,fanOn);} if(c=='R') tripped=false; }
  if(ds.isConversionComplete()){ lastTemp=ds.getTempCByIndex(0); lastAmb=ds.getTempCByIndex(1); ds.requestTemperatures(); }   // index 0 = motor body, 1 = ambient: check order once
  unsigned long ms;
#if SIM_WOKWI
  simControls(); setMotor(pwmDuty); digitalWrite(PIN_FAN,fanOn); simWindow();
  float motorT = simT + (lastTemp-25.0f);               // DS18B20 slider adds a manual heater offset (default value 25)
  ms=simMs; uint32_t p=pulses;
#else
  noInterrupts(); pulses=0; interrupts(); uint32_t t0=micros();
  for(int i=0;i<WINDOW_N;i++){
    while(micros()-t0 < (uint32_t)i*1000) {}
    Wire.beginTransmission(MPU); Wire.write(0x3B); Wire.endTransmission(false); Wire.requestFrom(MPU,(uint8_t)6);
    for(int k=0;k<3;k++) buf[i][k]=(Wire.read()<<8)|Wire.read();
    if(i%5==0){ buf[i][3]=rd16(INA,0x01); buf[i][4]=rd16(INA,0x02)>>3;
      if(I_MAX_MA>0 && fabsf(buf[i][3]*0.01f/0.1f)>I_MAX_MA) trip("over_current"); }
    else { buf[i][3]=-1; buf[i][4]=-1; }
  }
  uint32_t p; noInterrupts(); p=pulses; interrupts(); ms=millis(); float motorT=lastTemp;
#endif
  if(T_MAX_C>0 && motorT>T_MAX_C) trip("over_temp");
  Serial.printf("#WIN,%lu,%d,%d,%lu,%.2f,%.2f,%d\n",ms,pwmDuty,fanOn,(unsigned long)p,motorT,lastAmb,WINDOW_N);
  for(int i=0;i<WINDOW_N;i++) Serial.printf("r,%d,%d,%d,%d,%d\n",buf[i][0],buf[i][1],buf[i][2],buf[i][3],buf[i][4]);
  Serial.println("#END");
  delay(1000);
}
