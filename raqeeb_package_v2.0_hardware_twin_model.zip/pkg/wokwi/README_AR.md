# رقيب على Wokwi (نسخة v2) — الهاردوير المحاكى + الربط بالموديل

> ⚠ **لم يُجرَّب على Wokwi ولا على هاردوير فعلي** (كُتب بدون وصول لهما). اتفحصت صيغة `diagram.json` وأسماء الأطراف وصيغة الـ firmware (syntax فقط في الوضعين). الاختبار الفعلي أول تشغيل عندكم.

## ما الذي يُحاكى وما الذي لا يُحاكى (20 مكوّن)
| # | المكوّن | في Wokwi | ملاحظة |
|---|---|---|---|
| 1 | ESP32-WROOM-32 | ✔ `board-esp32-devkit-c-v4` | |
| 2 | MPU6050 | ✔ `wokwi-mpu6050` | قيمه ثابتة؛ الاهتزاز تُولّده الـ firmware (`SIM_WOKWI=1`) |
| 3 | INA219 | ✘ غير مُحاكى | لم أتأكد من وجود جزء رسمي؛ الـ firmware يولّد التيار والجهد في وضع المحاكاة |
| 4 | DS18B20 | ✔ ×2 | حرارة المحرك + حرارة الجو (أي ترتيب العناوين تأكدوا منه مرة) |
| 5 | GA25 + encoder | ✘ غير مُحاكى | النبضات/الـ rpm تُولَّد داخليًا (قيم مفترضة) |
| 6 | L298N | ✔ chip مجتمعي `chip-l298n` | LED كمؤشر للمحرك. يحتاج تحميل dependency من GitHub |
| 7 | مروحة + MOSFET | ◐ LED على GPIO14 | المروحة والـ MOSFET غير مُحاكيين كهربيًا |
| 8–20 | LM2596، بريدبورد، مقاومة 4.7k، مكثفات، وصلات، heat shrink، cable ties، مصدر 12V/5A، فيوز، terminal block، ديود SS34 | المقاومة فقط ✔ | الباقي للتركيب الفعلي (انظر `docs/HARDWARE_WIRING_AR.md`) |
| + | 3 مقاومات متغيرة | ✔ | السرعة (40/70/100)، نوع العطل (N,F1,F2,F3,F4)، الشدة (1/2) |
| + | زر Person | ✔ GPIO13 | |

## التشغيل
**أ) Wokwi أونلاين (الأسهل):** New Project → ESP32 (Arduino) → الصقوا `sketch.ino` و`diagram.json` و`libraries.txt` → Start. انسخوا مخرجات الـ Serial Monitor لملف `serial_log.txt` وشغّلوا:
`python runtime/bridge.py --replay serial_log.txt --enc-ppr 1000`  (إعادة تشغيل، مش لحظي)

**ب) VS Code + Wokwi extension (لحظي):** استخدموا `platformio.ini` و`wokwi.toml` (فيه `rfc2217ServerPort = 4000`) ثم:
`python runtime/bridge.py --port rfc2217://localhost:4000 --enc-ppr 1000`

**ج) هاردوير حقيقي:** غيّروا `SIM_WOKWI` إلى 0، واملوا ثوابت `I_MAX_MA` و`T_MAX_C` وقيمة `encoder_ppr_output_shaft` في `data/hardware_constants.json`، ثم `--port COM5`.

## ملاحظات
- المقاومات المتغيرة تتحكم في السيناريو: عطل F4 يطفئ LED المروحة ويرفع الحرارة تدريجيًا.
- حرارة الجو = قراءة DS18B20 الثاني. أي إضافة على حساس الموتور (الافتراضي 25) تُضاف كمُسخِّن يدوي.
- الـ firmware لا يعتمد على الـ bridge ولا على الموديل في حماية المحرك (FR-022).
