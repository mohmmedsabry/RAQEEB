// RAQEEB - ESP32 bench simulation (Wokwi)
// All values come from the SIMULATOR (sliders on the MPU6050 and DS18B20).
// They are simulated data, NOT real test results.
//
// What it shows (same flow as the project):
//   Motor -> Sensors -> ESP32 -> rules -> person decides -> verify after repair
// Thresholds are set from "normal-run" data measured at start (calibration).
// This is the THRESHOLD BASELINE. Isolation Forest runs later in Python on the logged CSV.

#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ---------- Pins ----------
const int PIN_DS18B20 = 4;
const int PIN_SDA     = 21;
const int PIN_SCL     = 22;
const int PIN_RELAY   = 26;   // relay powers the "Motor" LED
const int PIN_BUTTON  = 14;   // "Person" button to GND (INPUT_PULLUP)
const bool RELAY_ON_LEVEL = HIGH;   // flip to LOW if your relay is active-low

// ---------- Settings ----------
const uint8_t MPU_ADDR      = 0x68;
const int   SAMPLE_MS       = 20;    // 50 Hz
const int   WINDOW_SAMPLES  = 50;    // 1 s window
const int   CAL_WINDOWS     = 10;    // 10 s of normal run
const float K_SIGMA         = 3.0;   // limit = mean + K * std
const float MIN_STD_VIB     = 0.01;  // g
const float MIN_STD_TEMP    = 0.5;   // C
const float SIM_NOISE_G     = 0.02;  // simulated sensor noise (the simulator gives static values)
const int   WARN_COUNT      = 2;     // windows over limit -> review request
const int   ALARM_COUNT     = 5;     // windows over limit -> safe stop
const int   CLEAR_COUNT     = 3;     // windows normal -> clear warning
const int   VERIFY_WINDOWS  = 5;     // windows checked after restart

OneWire oneWire(PIN_DS18B20);
DallasTemperature sensors(&oneWire);

enum State { CALIBRATING, NORMAL, WARNING, ALARM, VERIFYING };
const char* STATE_NAME[] = { "CALIBRATING", "NORMAL", "WARNING", "ALARM", "VERIFYING" };
State state = CALIBRATING;

struct Stat {
  int n = 0; double mean = 0, m2 = 0;
  void add(double x) { n++; double d = x - mean; mean += d / n; m2 += d * (x - mean); }
  double sd() { return n > 1 ? sqrt(m2 / (n - 1)) : 0; }
};
Stat statVib, statTemp;

float buf[WINDOW_SAMPLES];
int   nSamp = 0;
float baseMag = 1.0; bool haveBase = false;
float vibLimit = 0, tempLimit = 0, lastTemp = 25.0;
int   calWin = 0, overCount = 0, okCount = 0, verWin = 0, failCount = 0;
float peakVib = 0, peakTemp = 0, sumVib = 0, sumTemp = 0;

void relay(bool on) { digitalWrite(PIN_RELAY, on ? RELAY_ON_LEVEL : !RELAY_ON_LEVEL); }

bool readAccel(float &ax, float &ay, float &az) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 6) != 6) return false;
  int16_t x = (Wire.read() << 8) | Wire.read();
  int16_t y = (Wire.read() << 8) | Wire.read();
  int16_t z = (Wire.read() << 8) | Wire.read();
  ax = x / 16384.0; ay = y / 16384.0; az = z / 16384.0;   // +-2 g range
  return true;
}

float readTemp() {
  float t = sensors.getTempCByIndex(0);
  sensors.requestTemperatures();               // start next conversion (non-blocking)
  if (t == DEVICE_DISCONNECTED_C) return lastTemp;
  lastTemp = t; return t;
}

bool buttonPressed() {
  static bool last = HIGH; static unsigned long t0 = 0;
  bool now = digitalRead(PIN_BUTTON);
  bool pressed = (last == HIGH && now == LOW && millis() - t0 > 250);
  if (pressed) t0 = millis();
  last = now; return pressed;
}

void handleButton() {
  if (state == ALARM) {
    relay(true); state = VERIFYING; verWin = 0; sumVib = 0; sumTemp = 0;
    Serial.println("# PERSON: acknowledged, motor restarted, verifying readings");
  } else if (state == WARNING) {
    state = NORMAL; overCount = 0; okCount = 0;
    Serial.println("# PERSON: reviewed, no fault confirmed");
  } else {
    Serial.println("# button ignored in this state");
  }
}

void processWindow() {
  if (!haveBase) {                       // first window only sets the rest level
    double s = 0; for (int i = 0; i < WINDOW_SAMPLES; i++) s += buf[i];
    baseMag = s / WINDOW_SAMPLES; haveBase = true; readTemp(); return;
  }
  double ss = 0;
  for (int i = 0; i < WINDOW_SAMPLES; i++) { double d = buf[i] - baseMag; ss += d * d; }
  float vib = sqrt(ss / WINDOW_SAMPLES);   // vibration RMS (g) around the rest level
  float t = readTemp();

  switch (state) {
    case CALIBRATING:
      statVib.add(vib); statTemp.add(t);
      if (++calWin >= CAL_WINDOWS) {
        vibLimit  = statVib.mean  + K_SIGMA * max((float)statVib.sd(),  MIN_STD_VIB);
        tempLimit = statTemp.mean + K_SIGMA * max((float)statTemp.sd(), MIN_STD_TEMP);
        state = NORMAL;
        Serial.printf("# thresholds from normal run: vib<=%.3f g, temp<=%.2f C\n", vibLimit, tempLimit);
      }
      break;
    default: {
      bool over = (vib > vibLimit) || (t > tempLimit);
      if (state == NORMAL) {
        if (over) { if (++overCount >= WARN_COUNT) {
          state = WARNING; okCount = 0; peakVib = vib; peakTemp = t;
          Serial.println("# REVIEW REQUEST: unusual reading, a person should check (an anomaly is not a confirmed fault)");
        } } else overCount = 0;
      } else if (state == WARNING) {
        peakVib = max(peakVib, vib); peakTemp = max(peakTemp, t);
        if (over) { okCount = 0;
          if (++overCount >= ALARM_COUNT) { state = ALARM; relay(false);
            Serial.printf("# SAFE STOP: relay off (peak vib %.3f g, temp %.2f C). Press the button to acknowledge\n", peakVib, peakTemp); }
        } else if (++okCount >= CLEAR_COUNT) { state = NORMAL; overCount = 0; okCount = 0;
          Serial.println("# cleared: readings back to normal"); }
      } else if (state == ALARM) {
        peakVib = max(peakVib, vib); peakTemp = max(peakTemp, t);
      } else if (state == VERIFYING) {
        sumVib += vib; sumTemp += t;
        if (++verWin >= VERIFY_WINDOWS) {
          float av = sumVib / VERIFY_WINDOWS, at = sumTemp / VERIFY_WINDOWS;
          if (av <= vibLimit && at <= tempLimit) { state = NORMAL; overCount = 0;
            Serial.printf("# VERIFIED: before peak vib %.3f g / %.2f C, after avg vib %.3f g / %.2f C -> task closed\n", peakVib, peakTemp, av, at);
          } else { state = ALARM; relay(false);
            Serial.printf("# REOPEN: still abnormal after restart (avg vib %.3f g, %.2f C) -> escalate\n", av, at); }
        }
      }
    }
  }
  Serial.printf("%lu,%.2f,%.3f,%s,%.3f,%.2f\n", millis(), t, vib, STATE_NAME[state], vibLimit, tempLimit);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_RELAY, OUTPUT); relay(true);          // motor running
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.beginTransmission(MPU_ADDR); Wire.write(0x6B); Wire.write(0); Wire.endTransmission();  // wake MPU6050
  sensors.begin(); sensors.setWaitForConversion(false); sensors.requestTemperatures();
  Serial.println("# RAQEEB bench simulation - SIMULATED data only");
  Serial.println("# calibrating on normal run (~11 s): keep sliders at normal values");
  Serial.println("# columns: ms,temp_c,vib_rms_g,state,vib_limit_g,temp_limit_c");
}

void loop() {
  static unsigned long next = 0;
  unsigned long now = millis();
  if (now >= next) {
    next = now + SAMPLE_MS;
    float ax, ay, az;
    if (readAccel(ax, ay, az)) {
      float noise = (random(-1000, 1001) / 1000.0f) * SIM_NOISE_G;
      buf[nSamp++] = sqrtf(ax * ax + ay * ay + az * az) + noise;
    } else if (++failCount % 100 == 1) {
      Serial.println("# MPU6050 not responding - check wiring");
    }
    if (nSamp >= WINDOW_SAMPLES) { processWindow(); nSamp = 0; }
  }
  if (buttonPressed()) handleButton();
}
