"""RAQEEB runtime bridge:  ESP32 stream (real serial / Wokwi RFC2217 / digital twin) -> data-quality gate -> features -> AI model -> decisions -> SQLite + CSV.
The bridge NEVER commands actuators. Local protection (current/temperature trip) stays on the ESP32 and does not depend on this program.
Usage:  python simulator/twin.py --scenario simulator/demo_scenario.json | python runtime/bridge.py --stdin
        python runtime/bridge.py --port COM5            (real hardware)       python runtime/bridge.py --port rfc2217://localhost:4000   (Wokwi)"""
import argparse, collections, json, os, sqlite3, sys, time
import numpy as np, pandas as pd
here=os.path.dirname(os.path.abspath(__file__)); sys.path[:0]=[os.path.join(here,"..","tools"),os.path.join(here,"..","model")]
import logger_pc; from raqeeb_model import RaqeebModel, FEATS
CADENCE_MS=5000
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--stdin",action="store_true"); ap.add_argument("--port"); ap.add_argument("--baud",type=int,default=921600); ap.add_argument("--replay")
    ap.add_argument("--model",default=os.path.join(here,"..","models","raqeeb_model_v1.0.joblib")); ap.add_argument("--db",default=os.path.join(here,"raqeeb_runtime.db"))
    ap.add_argument("--out",default=os.path.join(here,"out")); ap.add_argument("--enc-ppr",type=float,default=None); ap.add_argument("--quiet",action="store_true"); a=ap.parse_args()
    hc=json.load(open(os.path.join(here,"..","data","hardware_constants.json")))["must_confirm_before_power_on"]["encoder_ppr_output_shaft"]["value"]
    ppr=a.enc_ppr or hc
    if ppr is None: sys.exit("encoder_ppr_output_shaft is not set (data/hardware_constants.json) and --enc-ppr not given. Refusing to guess rpm.")
    if a.enc_ppr: print(f"# WARNING: using --enc-ppr {a.enc_ppr} (ASSUMED value, not from GA25 datasheet)",file=sys.stderr)
    logger_pc.ENC_PPR_OUT=ppr; model=RaqeebModel.load(a.model); os.makedirs(a.out,exist_ok=True)
    db=sqlite3.connect(a.db); db.executescript("""CREATE TABLE IF NOT EXISTS windows(record_id TEXT PRIMARY KEY,session TEXT,ms INTEGER,elapsed_min REAL,pwm_duty INTEGER,fan_state INTEGER,temperature_value REAL,ambient_temp_C REAL,
        temp_delta_C REAL,rpm REAL,current_mean_mA REAL,vib_rms_total REAL,amp_1x REAL,vib_kurtosis REAL,zone INTEGER,if_score REAL,thermal_resid REAL,reason TEXT,status TEXT,model_version TEXT);
      CREATE TABLE IF NOT EXISTS events(event_id TEXT PRIMARY KEY,session TEXT,ms INTEGER,elapsed_min REAL,type TEXT,details TEXT);
      CREATE TABLE IF NOT EXISTS data_quality(dq_id TEXT PRIMARY KEY,session TEXT,ms INTEGER,issue TEXT,details TEXT);""")
    src=sys.stdin if a.stdin else (open(a.replay) if a.replay else __import__("serial").serial_for_url(a.port,a.baud,timeout=5))
    lines=(l if isinstance(l,str) else l.decode(errors="ignore") for l in iter(src.readline,"" if (a.stdin or a.replay) else b""))
    st=dict(session="unnamed",ms0=None,last_ms=None,temps=[],zones=collections.deque(maxlen=5),alert=False,review=False,seen=set()); counts=collections.Counter(); ev_n=[0]
    def event(typ,ms,el,**d):
        ev_n[0]+=1; eid=f"EV{ev_n[0]:05d}"; db.execute("INSERT INTO events VALUES(?,?,?,?,?,?)",(eid,st["session"],ms,el,typ,json.dumps(d,ensure_ascii=False))); counts[typ]+=1
        if not a.quiet: print(json.dumps(dict(event=typ,session=st["session"],elapsed_min=round(el,2),**d),ensure_ascii=False))
    def dq(ms,issue,**d):
        k=f"DQ{sum(counts[x] for x in counts if x.startswith('dq_'))+1:05d}"; counts["dq_"+issue]+=1; db.execute("INSERT INTO data_quality VALUES(?,?,?,?,?)",(k,st["session"],ms,issue,json.dumps(d)))
        if not a.quiet: print(json.dumps(dict(data_quality=issue,session=st["session"],ms=ms,**d)))
    for w in logger_pc.parse_stream(lines):
        if "session" in w: st.update(session=w["session"],ms0=None,last_ms=None,temps=[],alert=False,review=False,seen=set()); st["zones"].clear(); continue
        if "trip" in w: event("ESP32_PROTECTION_TRIP",st["last_ms"] or 0,0.0,reason=w["trip"],note="local protection acted; no model involvement"); continue
        if "bad_window" in w: dq(st["last_ms"] or 0,"invalid_incomplete_window",detail=w["bad_window"]); continue
        ms=w["ms"]
        if ms in st["seen"]: dq(ms,"duplicate_window_ignored"); continue
        st["seen"].add(ms)
        if st["ms0"] is None: st["ms0"]=ms-0
        if st["last_ms"] is not None and ms-st["last_ms"]>3*CADENCE_MS: dq(ms,"stale_gap",gap_ms=ms-st["last_ms"]); st["temps"]=[]; st["zones"].clear()
        st["last_ms"]=ms; el=(ms-st["ms0"])/60000.0
        if w["temp"]<=-100 or not np.isfinite(w["temp"]): dq(ms,"invalid_motor_temp_sensor",value=w["temp"]); continue
        if w["amb"]<=-100 or not np.isfinite(w["amb"]): dq(ms,"invalid_ambient_sensor",value=w["amb"]); continue
        f=logger_pc.to_features(w)
        if not np.isfinite(f["rpm"]) or f["current_mean_mA"]<=0: dq(ms,"invalid_rpm_or_current",rpm=f["rpm"],current=f["current_mean_mA"]); continue
        st["temps"].append(f["temperature_value"]); T=st["temps"]; i=len(T)-1; j=max(0,i-12)
        f.update(elapsed_min=round(el,3),temp_slope_C_min=round((T[i]-T[j])/((i-j)*CADENCE_MS/60000.0),3) if i>=6 else 0.0,temp_delta_C=round(f["temperature_value"]-f["ambient_temp_C"],2))
        P=model.predict(pd.DataFrame([f])).iloc[0]; z=int(P.zone); st["zones"].append(z); rid=f"{st['session']}_{ms}"
        db.execute("INSERT OR IGNORE INTO windows VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(rid,st["session"],ms,el,f["pwm_duty"],f["fan_state"],f["temperature_value"],f["ambient_temp_C"],f["temp_delta_C"],f["rpm"],
            f["current_mean_mA"],f["vib_rms_total"],f["amp_1x"],f["vib_kurtosis"],z,None if pd.isna(P.if_score) else float(P.if_score),float(P.thermal_resid),P.reason,"ok",P.model_version)); counts["windows"]+=1; counts[f"zone{z}"]+=1
        Z=list(st["zones"]); ev=dict(reason=P.reason,top_deviations=P.top_deviations,model_version=P.model_version)
        if len(Z)==5 and sum(1 for x in Z if x==2)>=3 and not st["alert"]:
            st["alert"]=True; event("ALERT",ms,el,recommended_action="human review; decide on safe stop (ESP32 local protection is independent of this alert)",requires_human_review=True,**ev)
        elif len(Z)==5 and all(x>=1 for x in Z) and not st["review"] and not st["alert"]:
            st["review"]=True; event("REVIEW_REQUEST",ms,el,recommended_action="open case in review queue",requires_human_review=True,**ev)
        if len(Z)==5 and all(x==0 for x in Z) and (st["alert"] or st["review"]): st["alert"]=st["review"]=False; event("CLEARED",ms,el,note="5 consecutive normal windows")
        if counts["windows"]%25==0: db.commit()
    db.commit()
    for t in ("windows","events","data_quality"): pd.read_sql(f"SELECT * FROM {t}",db).to_csv(os.path.join(a.out,f"{t}.csv"),index=False)
    print("# SUMMARY",json.dumps(dict(counts),ensure_ascii=False),file=sys.stderr)
if __name__=="__main__": main()
