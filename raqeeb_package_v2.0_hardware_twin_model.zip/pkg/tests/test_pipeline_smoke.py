"""End-to-end smoke test: twin -> bridge -> model -> SQLite.  python tests/test_pipeline_smoke.py   (exit 0 = all pass)"""
import json, os, sqlite3, subprocess, sys, tempfile
root=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
sc={"sessions":[{"name":"t1","ambient":27.0,"seed":21,"mount":1.0,"segments":[{"minutes":3,"pwm":70,"load":"none","fan":1,"fault":"N"},{"minutes":1,"pwm":70,"load":"none","fan":1,"fault":"F1","sev":2}]},
  {"name":"t2","ambient":27.0,"seed":22,"mount":1.0,"segments":[{"minutes":1,"pwm":100,"load":"none","fan":1,"fault":"N"},{"minutes":0.25,"pwm":100,"load":"none","fan":1,"fault":"N","inject":{"kind":"temp_disconnected","windows":3}},{"minutes":0.5,"pwm":100,"load":"none","fan":1,"fault":"N"}]}]}
d=tempfile.mkdtemp(); p=os.path.join(d,"sc.json"); json.dump(sc,open(p,"w")); db=os.path.join(d,"t.db")
tw=subprocess.run([sys.executable,os.path.join(root,"simulator","twin.py"),"--scenario",p],capture_output=True,text=True,check=True).stdout
# duplicate a window block on purpose (idempotency): repeat the first window lines
first=tw.split("#WIN",2)[1]; tw_dup=tw+"#WIN"+first
r=subprocess.run([sys.executable,os.path.join(root,"runtime","bridge.py"),"--stdin","--db",db,"--out",d,"--enc-ppr","1000","--quiet"],input=tw_dup,capture_output=True,text=True)
con=sqlite3.connect(db); q=lambda s:con.execute(s).fetchall(); ok=True
def check(name,cond):
    global ok; ok&=bool(cond); print(("PASS " if cond else "FAIL ")+name)
ev=q("select type,session,elapsed_min from events"); dqs=q("select issue from data_quality")
check("bridge exit code 0",r.returncode==0)
check("F1 session raises ALERT within 60 s of fault onset (t=3.0 min)",any(t=="ALERT" and s=="t1" and 3.0<=m<=4.0 for t,s,m in ev))
check("no ALERT during first 3 normal minutes of t1",not any(t=="ALERT" and s=="t1" and m<3.0 for t,s,m in ev))
check("disconnected temp sensor logged as data-quality issue (3x)",sum(1 for (i,) in dqs if i=="invalid_motor_temp_sensor")==3)
check("duplicate window ignored and logged",any(i=="duplicate_window_ignored" for (i,) in dqs))
check("invalid windows never reach the model: t2 has 21 windows, 3 invalid -> exactly 18 rows",q("select count(*) from windows where session='t2'")[0][0]==18)
check("window ids unique (idempotent inserts)",q("select count(*)-count(distinct record_id) from windows")[0][0]==0)
sys.exit(0 if ok else 1)
