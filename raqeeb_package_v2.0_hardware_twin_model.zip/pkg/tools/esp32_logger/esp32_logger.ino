// RAQEEB bench logger  --  DRAFT, NOT TESTED ON HARDWARE. Verify every constant below before powering the motor.
// Libraries: OneWire, DallasTemperature.  Board: ESP32 Dev Module.  Serial 921600.
#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
// ---- pins (see pin map) ----
const int PIN_ENA=25, PIN_IN1=26, PIN_IN2=27, PIN_FAN=14, PIN_ENC_A=34, PIN_ONEWIRE=4;
// ---- TODO values from datasheets / baseline runs ----
const float I_MAX_MA = 0;      // TODO: trip current (from measured normal-run baseline and driver rating)
const float T_MAX_C  = 0;      // TODO: motor datasheet limit with margin
const int   WINDOW_N = 2000;   // 2 s at 1 kHz
const uint8_t MPU=0x68, INA=0x40;
OneWire ow(PIN_ONEWIRE); DallasTemperature ds(&ow);
volatile uint32_t pulses=0; void IRAM_ATTR isrEnc(){ pulses++; }
int pwmDuty=0, fanOn=0; float lastTemp=NAN, lastAmb=NAN; bool tripped=false;
void wr8(uint8_t a,uint8_t r,uint8_t v){Wire.beginTransmission(a);Wire.write(r);Wire.write(v);Wire.endTransmission();}
int16_t rd16(uint8_t a,uint8_t r){Wire.beginTransmission(a);Wire.write(r);Wire.endTransmission(false);Wire.requestFrom(a,(uint8_t)2);return (Wire.read()<<8)|Wire.read();}
void setMotor(int duty){ pwmDuty=constrain(duty,0,100); digitalWrite(PIN_IN1,pwmDuty>0); digitalWrite(PIN_IN2,LOW); ledcWrite(PIN_ENA, map(pwmDuty,0,100,0,255)); }
void trip(const char* why){ setMotor(0); tripped=true; Serial.printf("#TRIP,%s\n",why); }
void setup(){
  Serial.begin(921600); Wire.begin(21,22); Wire.setClock(400000);
  pinMode(PIN_IN1,OUTPUT); pinMode(PIN_IN2,OUTPUT); pinMode(PIN_FAN,OUTPUT); pinMode(PIN_ENC_A,INPUT);
  ledcAttach(PIN_ENA,20000,8);                       // arduino-esp32 v3 API; v2: ledcSetup+ledcAttachPin
  attachInterrupt(PIN_ENC_A,isrEnc,RISING);
  wr8(MPU,0x6B,0x00); wr8(MPU,0x1A,0x00); wr8(MPU,0x19,0x07); wr8(MPU,0x1C,0x08);   // wake, DLPF off, 8k/(1+7)=1 kHz, +-4 g
  ds.begin(); ds.setWaitForConversion(false); ds.requestTemperatures();
  setMotor(0);
}
void loop(){
  while(Serial.available()){ char c=Serial.read(); if(c=='P'){ int d=Serial.parseInt(); if(!tripped) setMotor(d);} if(c=='F'){ fanOn=Serial.parseInt(); digitalWrite(PIN_FAN,fanOn);} if(c=='R'){ tripped=false; } }
  if(ds.isConversionComplete()){ lastTemp=ds.getTempCByIndex(0); lastAmb=ds.getTempCByIndex(1); ds.requestTemperatures(); }   // index 0 = motor body, 1 = ambient (check address order once)
  if(T_MAX_C>0 && lastTemp>T_MAX_C) trip("over_temp");
  noInterrupts(); pulses=0; interrupts();
  static int16_t buf[WINDOW_N][5]; uint32_t t0=micros();
  for(int i=0;i<WINDOW_N;i++){
    while(micros()-t0 < (uint32_t)i*1000) {}
    Wire.beginTransmission(MPU); Wire.write(0x3B); Wire.endTransmission(false); Wire.requestFrom(MPU,(uint8_t)6);
    for(int k=0;k<3;k++) buf[i][k]=(Wire.read()<<8)|Wire.read();
    if(i%5==0){ buf[i][3]=rd16(INA,0x01); buf[i][4]=rd16(INA,0x02)>>3;
      if(I_MAX_MA>0 && fabs(buf[i][3]*0.01/0.1)>I_MAX_MA) trip("over_current"); }
    else { buf[i][3]=-1; buf[i][4]=-1; }
  }
  uint32_t p; noInterrupts(); p=pulses; interrupts();
  Serial.printf("#WIN,%lu,%d,%d,%lu,%.2f,%.2f,%d\n",millis(),pwmDuty,fanOn,(unsigned long)p,lastTemp,lastAmb,WINDOW_N);
  for(int i=0;i<WINDOW_N;i++) Serial.printf("r,%d,%d,%d,%d,%d\n",buf[i][0],buf[i][1],buf[i][2],buf[i][3],buf[i][4]);
  Serial.println("#END");
  delay(3000-0);   // ~5 s cadence incl. transfer
}
