"""Reference feature extractor: raw 2-s window -> one feature row (same columns as the features CSVs).
Use it on REAL recordings. Definitions (also in schema.md):
 - axes are demeaned per window (gravity/DC removed); vib_rms_total = sqrt(rx^2+ry^2+rz^2)
 - shape stats (peak, p2p, crest, kurtosis, skew) computed on the 1st principal component of the 3 demeaned axes
 - spectrum: Welch-free single rfft (Hann) of the principal component; bands are power FRACTIONS of 0-500 Hz
 - amp_1x: spectral amplitude (g) within +-1 Hz of shaft frequency rpm/60 ; dom_freq_hz: peak bin above 5 Hz"""
import numpy as np
BANDS=[("band_0_50",0,50),("band_50_150",50,150),("band_150_250",150,250),("band_250_500",250,500)]
def _kurt(x): s=x.std(); return float(np.mean(((x-x.mean())/s)**4)) if s>0 else 0.0
def _skew(x): s=x.std(); return float(np.mean(((x-x.mean())/s)**3)) if s>0 else 0.0
def extract(ax, ay, az, fs, rpm, temp_c, cur_mA, bus_V, pwm, fan_state, temp_slope=0.0, ambient_c=None):
    A=np.vstack([np.asarray(v,float)-np.mean(v) for v in (ax,ay,az)])
    rms=np.sqrt((A**2).mean(axis=1)); tot=float(np.sqrt((rms**2).sum()))
    pc=A.T@ (np.linalg.svd(A,full_matrices=False)[0][:,0])   # projection onto 1st principal axis (g)
    peak=float(np.abs(pc).max()); p2p=float(pc.max()-pc.min()); r=float(np.sqrt((pc**2).mean()))
    w=np.hanning(len(pc)); F=np.abs(np.fft.rfft(pc*w))*2/ w.sum(); f=np.fft.rfftfreq(len(pc),1/fs); P=F**2
    sel=(f>0)&(f<=500); tp=P[sel].sum() or 1e-12
    bands={n:float(P[(f>lo)&(f<=hi)].sum()/tp) for n,lo,hi in BANDS}
    f1=rpm/60.0; m1=(f>=f1-1)&(f<=f1+1); amp1=float(F[m1].max()) if m1.any() else 0.0
    hm=f>5; dom=float(f[hm][np.argmax(F[hm])]) if hm.any() else 0.0
    cent=float((f[sel]*P[sel]).sum()/tp)
    cur=np.asarray(cur_mA,float)
    return dict(temperature_value=round(temp_c,2),ambient_temp_C=round(ambient_c,2),temp_delta_C=round(temp_c-ambient_c,2),temp_slope_C_min=temp_slope,rpm=round(rpm,1),pwm_duty=pwm,fan_state=fan_state,
      current_mean_mA=round(cur.mean(),1),current_std_mA=round(cur.std(),1),current_max_mA=round(cur.max(),1),bus_voltage_V=round(float(np.mean(bus_V)),3),
      ax_rms=round(rms[0],5),ay_rms=round(rms[1],5),az_rms=round(rms[2],5),vib_rms_total=round(tot,5),vib_peak=round(peak,5),vib_p2p=round(p2p,5),
      vib_crest=round(peak/r,3) if r>0 else 0.0,vib_kurtosis=round(_kurt(pc),3),vib_skew=round(_skew(pc),3),dom_freq_hz=round(dom,2),
      spec_centroid_hz=round(cent,1),**{k:round(v,4) for k,v in bands.items()},amp_1x=round(amp1,5))
