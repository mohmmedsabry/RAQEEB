"""Validation gate.  python tools/validate_data.py data/data.csv
                    python tools/validate_data.py staging/skab.csv --profile profiles/skab.json
Exit code 0 only if ALL checks pass.  Use on every new recording / external staging file BEFORE it is appended or used."""
import argparse, json, sys, pandas as pd, numpy as np
ap=argparse.ArgumentParser(); ap.add_argument("path",nargs="?",default="data/data.csv"); ap.add_argument("--profile"); a=ap.parse_args()
sch=json.load(open(a.profile or "schema/data_schema.json")); df=pd.read_csv(a.path)
req=sch["required"]; props=sch["properties"]; errs=[]; checks=0; has=lambda *c: all(x in df.columns for x in c)
def chk(name,bad):
    global checks; checks+=1; n=int(bad.sum()) if hasattr(bad,"sum") else int(bad)
    if n: errs.append(f"{name}: {n} violations")
chk("columns match schema/profile exactly",0 if list(df.columns)==list(req) else 1)
chk("no missing values (NaN/empty)",df.isna().sum().sum())
for c,p in props.items():
    if c not in df: continue
    s=df[c]
    if p.get("unique"): chk(f"{c} unique",s.duplicated())
    if "enum" in p: chk(f"{c} in allowed values",~s.isin(p["enum"]))
    if p.get("type") in("number",) :
        chk(f"{c} numeric",pd.to_numeric(s,errors="coerce").isna()); chk(f"{c} within [{p['minimum']},{p['maximum']}]",(s<p["minimum"])|(s>p["maximum"]))
    if "pattern" in p: chk(f"{c} matches pattern",~s.astype(str).str.contains(p["pattern"],regex=True))
t=pd.to_datetime(df.timestamp,errors="coerce"); chk("timestamp parseable",t.isna())
chk("timestamps increase inside session",df.assign(t=t).groupby("session_id").t.apply(lambda x:(x.diff().dropna()<=pd.Timedelta(0)).sum()))
chk("session in exactly one split",df.groupby("session_id").split.nunique()>1)
if has("label_binary","fault_type"): chk("label_binary == (fault_type != N)",df.label_binary!=(df.fault_type!="N").astype(int))
if has("severity","fault_type"): chk("severity==0 iff N",(df.severity==0)!=(df.fault_type=="N"))
B=["band_0_50","band_50_150","band_150_250","band_250_500"]
if has(*B): chk("bands sum to 1 (+-0.01)",(df[B].sum(axis=1)-1).abs()>0.01)
if has("fault_type","fan_state"): chk("F4 has fan off",(df.fault_type=="F4")&(df.fan_state!=0))
if has("vib_rms_total","ax_rms","ay_rms","az_rms"): chk("vib_rms_total >= each axis rms",df.vib_rms_total+1e-9<df[["ax_rms","ay_rms","az_rms"]].max(axis=1))
if has("current_max_mA","current_mean_mA"): chk("current_max >= current_mean",df.current_max_mA<df.current_mean_mA)
if not a.profile and has("session_id","fault_type"): chk("normal rows only in N sessions",df.session_id.str.contains("_N").ne(df.fault_type.eq("N")))
if has("temp_delta_C","temperature_value","ambient_temp_C"): chk("temp_delta == temperature - ambient",(df.temp_delta_C-(df.temperature_value-df.ambient_temp_C)).abs()>0.011)
if has("load_state","regime"): chk("load_state consistent with regime",df.load_state.ne(np.where(df.regime.isin(["R1","R3","R5"]),"none","light")))
if has("elapsed_min","session_id"):
    chk("elapsed_min starts at 0 per session",df.groupby("session_id").elapsed_min.min()!=0)
    chk("elapsed_min increases inside session",df.groupby("session_id").elapsed_min.apply(lambda x:(x.diff().dropna()<=0).sum()))
    if has("fault_type"): chk("F4 sessions >= 9.5 min",df[df.fault_type=="F4"].groupby("session_id").elapsed_min.max()<9.5)
rep={"file":a.path,"profile":a.profile or "default","rows":len(df),"columns":df.shape[1],"sessions":int(df.session_id.nunique()),"checks_run":checks,
     "violations":errs,"status":"PASS" if not errs else "FAIL","rows_by_split":df.split.value_counts().to_dict()}
print(json.dumps(rep,indent=1,ensure_ascii=False)); sys.exit(0 if not errs else 1)
