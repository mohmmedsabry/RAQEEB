"""RAQEEB digital twin of the bench hardware (ESP32 + MPU6050 + INA219 + 2x DS18B20 + GA25 encoder + fan).
Generates WIRE-LEVEL data (raw int counts, exactly what the ESP32 sends) so it goes through the SAME logger -> extractor -> model path as real hardware.
EVERYTHING HERE IS SIMULATED. Constants marked ASSUMED must be replaced by GA25 datasheet / real measurements."""
import json, sys, time
import numpy as np
FS=1000; N=2000; WIN_S=2.0; CADENCE_S=5.0
ENC_PPR_OUT=1000          # ASSUMED pulses per OUTPUT-shaft revolution (GA25 datasheet needed)
SPEED_RPM={40:120,70:220,100:320}   # ASSUMED output rpm per pwm setpoint
TEETH=15                  # ASSUMED gear-mesh multiplier
ACC_LSB=8192.0            # MPU6050 +-4 g
SHUNT_OHM=0.1             # INA219 shunt (ASSUMED module default)
class MotorTwin:
    def __init__(self,seed=0,ambient=27.0,mount=1.0,t0_offset=None):
        self.r=np.random.default_rng(seed); self.amb=ambient; self.mount=mount; self.t_s=0.0; self.ms=0
        self.T=ambient+(t0_offset if t0_offset is not None else self.r.uniform(1,3.5)); self.pwm=70; self.load=0; self.fan=1; self.fault="N"; self.sev=0
        self.inject=None; self._inj_left=0
    def set(self,pwm=None,load=None,fan=None,fault=None,sev=None,ambient=None):
        if pwm is not None: self.pwm=pwm
        if load is not None: self.load=1 if load in(1,"light") else 0
        if fan is not None: self.fan=int(fan)
        if fault is not None: self.fault=fault
        if sev is not None: self.sev=sev
        if ambient is not None: self.amb=ambient
    def inject_failure(self,kind,windows): self.inject=kind; self._inj_left=windows
    def _lowpass(self,x,fc=260.0):
        F=np.fft.rfft(x); f=np.fft.rfftfreq(len(x),1/FS); F[f>fc]=0; return np.fft.irfft(F,len(x))
    def window(self):
        r=self.r; rpm0=SPEED_RPM[self.pwm]; load=self.load; f,s=self.fault,self.sev
        rpm=rpm0*(1-0.03*load)*(1-(0.055*s if f=="F3" else 0))+r.normal(0,1.2)
        f1=rpm/60.0; mesh=TEETH*f1; t=np.arange(N)/FS
        a1=abs(r.normal(0.004,0.0005))*(rpm0/200)*self.mount
        if f=="F1": a1+=0.009*s*(rpm0/200)**2
        sig_b=(0.012+0.00005*rpm0)*self.mount*(1+(0.14*s if f=="F2" else 0)+(0.07*s if f=="F3" else 0))
        def axis(k,ph):
            x=a1*np.sin(2*np.pi*f1*t+ph)+0.012*(rpm0/200)*np.sin(2*np.pi*mesh*t+ph*1.7)+sig_b*r.standard_normal(N)*0.6
            if f=="F3": x+=0.004*s*np.sin(2*np.pi*2*f1*t+ph)
            return k*x
        ax,ay,az=axis(1.0,r.uniform(0,6.28)),axis(0.6,r.uniform(0,6.28)),axis(0.8,r.uniform(0,6.28))
        if f=="F2":      # loose mounting: impacts ringing at ~180 Hz
            imp=np.zeros(N); idx=r.choice(N,int(25*s),replace=False); imp[idx]=r.choice([-1,1],len(idx))*r.uniform(.08,.18,len(idx))*s
            k=np.exp(-np.arange(40)/8.0)*np.sin(2*np.pi*180*np.arange(40)/FS); ring=np.convolve(imp,k,mode="same")
            ax+=ring; ay+=0.7*ring; az+=0.8*ring
        out=[]
        for v,off in ((ax,0.02),(ay,-0.01),(az,1.0)):
            v=self._lowpass(v+0.0065*r.standard_normal(N))+off          # MEMS noise ~6.5 mg rms, 260 Hz bandwidth, gravity offset
            out.append(np.clip(np.round(v*ACC_LSB),-32768,32767).astype(np.int32))
        i_mean=(120+0.9*rpm0+90*load)*(1+(0.33*s if f=="F3" else 0)); i_std=(18+6*load)*(1+(0.7*s if f=="F3" else 0))
        cur=i_mean*r.normal(1,.015)+r.normal(0,i_std,N//5)
        shunt=np.round(cur*10).astype(np.int32); bus=np.round((11.85-0.0012*cur+r.normal(0,.03,N//5))/0.004).astype(np.int32)
        sh=np.full(N,-1,np.int32); bu=np.full(N,-1,np.int32); sh[::5]=shunt; bu[::5]=bus
        tss=self.amb+5+0.022*rpm0+2.5*load-(4 if self.fan else 0)+(7*s if f=="F4" else 0); tau=600.0 if f=="F4" else 420.0
        self.T+=(tss-self.T)*(1-np.exp(-CADENCE_S/tau))
        if f=="F3": self.T+=0.0
        t_read=np.round((self.T+r.normal(0,.05))/0.0625)*0.0625; a_read=np.round((self.amb+r.normal(0,.08))/0.0625)*0.0625
        pulses=int(round(rpm/60.0*WIN_S*ENC_PPR_OUT+r.normal(0,1)))
        fault_inj=None
        if self._inj_left>0:
            fault_inj=self.inject; self._inj_left-=1
            if fault_inj=="temp_disconnected": t_read=-127.0
            if fault_inj=="ambient_disconnected": a_read=-127.0
        self.ms+=int(CADENCE_S*1000); self.t_s+=CADENCE_S
        rows=np.stack([out[0],out[1],out[2],sh,bu],axis=1)
        return dict(ms=self.ms,pwm=self.pwm,fan=self.fan,pulses=pulses,temp=float(t_read),amb=float(a_read),n=N,rows=rows,_inject=fault_inj)
def to_lines(w,drop_end=False):
    L=[f"#WIN,{w['ms']},{w['pwm']},{w['fan']},{w['pulses']},{w['temp']:.2f},{w['amb']:.2f},{w['n']}"]
    L+=[f"r,{a},{b},{c},{d},{e}" for a,b,c,d,e in w["rows"].tolist()]
    if not drop_end: L.append("#END")
    return L
def run_scenario(sc,speedup=0.0,out=sys.stdout):
    """sc = {"sessions":[{"name","ambient","seed","mount","segments":[{"minutes","pwm","load","fan","fault","sev","inject":{"kind","windows"}}]}]}"""
    for s in sc["sessions"]:
        tw=MotorTwin(seed=s.get("seed",0),ambient=s.get("ambient",27.0),mount=s.get("mount",1.0)); out.write(f"#SESSION,{s['name']}\n")
        for seg in s["segments"]:
            tw.set(pwm=seg.get("pwm"),load=seg.get("load"),fan=seg.get("fan"),fault=seg.get("fault","N"),sev=seg.get("sev",0))
            if "inject" in seg: tw.inject_failure(seg["inject"]["kind"],seg["inject"]["windows"])
            for _ in range(int(round(seg["minutes"]*60/CADENCE_S))):
                w=tw.window()
                if w["_inject"]=="drop_window": continue
                out.write("\n".join(to_lines(w,drop_end=(w["_inject"]=="truncated")))+"\n"); out.flush()
                if speedup>0: time.sleep(CADENCE_S/speedup)
if __name__=="__main__":
    import argparse; ap=argparse.ArgumentParser(); ap.add_argument("--scenario",required=True); ap.add_argument("--speedup",type=float,default=0.0); a=ap.parse_args()
    run_scenario(json.load(open(a.scenario)),a.speedup)
