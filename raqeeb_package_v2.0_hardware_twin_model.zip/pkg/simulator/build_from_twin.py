"""Build dataset v2.0 by running the digital twin through the SAME path as real hardware:  twin (raw wire-level windows) -> logger_pc.to_features (extract_features.py) -> rows.
Schedule/splits/columns are identical to build_v12 (same sessions, same days). All data is SIMULATED (source=simulated)."""
import os, sys, numpy as np, pandas as pd
here=os.path.dirname(os.path.abspath(__file__)); sys.path[:0]=[os.path.join(here,"..","tools"),here]
import build_v12 as B, generate_dataset as g, logger_pc
from twin import MotorTwin, ENC_PPR_OUT, CADENCE_S
logger_pc.ENC_PPR_OUT=ENC_PPR_OUT
PWM={"S1":40,"S2":70,"S3":100}
def twin_sess(sid,reg,fault,sev,n,start,amb,mount,fan):
    sp,load=g.REGIMES[reg]; tw=MotorTwin(seed=int(g.rng.integers(0,2**31)),ambient=float(amb+g.rng.normal(0,.3)),mount=float(mount),t0_offset=float(g.rng.uniform(1,3.5)))
    tw.set(pwm=PWM[sp],load=load,fan=fan,fault=fault or "N",sev=sev); rows=[]
    for i in range(n):
        f=logger_pc.to_features(tw.window())
        f.update(session_id=sid,timestamp=(start+pd.Timedelta(seconds=i*CADENCE_S)).strftime("%Y-%m-%d %H:%M:%S"),elapsed_min=round(i*CADENCE_S/60,3),
                 load_state="light" if load else "none",regime=reg,fault_type=fault or "N",severity=sev); rows.append(f)
    return rows
B.sess=twin_sess
if __name__=="__main__":
    out=os.path.join(here,".."); B.write_all(*B.build(),out)
