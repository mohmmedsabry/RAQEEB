"""SKAB -> RAQEEB common-features staging file.  Values are NOT altered except unit conversion (A -> mA).
Usage: python adapters/skab_to_raqeeb.py --src ext/skab/data --out staging/skab.csv
Mapping: Temperature->temperature_value | Current(A)*1000->current_mean_mA | Voltage->bus_voltage_V
         vib_rms_total = sqrt(Acc1RMS^2 + Acc2RMS^2)  (ASSUMPTION: combined RMS of the 2 accelerometers)
         anomaly->label_binary ; fault_type N/X ; Thermocouple/Pressure/Flow kept as extra columns.
Rows with any missing sensor value are dropped and counted (never imputed).  Split is by SESSION (sha1 hash of file name)."""
import argparse, glob, hashlib, json, os
import numpy as np, pandas as pd
SENS=["Accelerometer1RMS","Accelerometer2RMS","Current","Pressure","Temperature","Thermocouple","Voltage","Volume Flow RateRMS"]
def split_of(name):
    h=int(hashlib.sha1(name.encode()).hexdigest(),16)%10
    return "train" if h<6 else ("val" if h<8 else "test")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--src",required=True); ap.add_argument("--out",required=True); a=ap.parse_args()
    files=sorted(glob.glob(os.path.join(a.src,"**","*.csv"),recursive=True)); out=[]; log=dict(files=len(files),dropped_rows=0,dropped_dupe_ts=0)
    for f in files:
        d=pd.read_csv(f,sep=";"); rel=os.path.relpath(f,a.src).replace(os.sep,"_").replace(".csv","")
        miss=d[SENS].isna().any(axis=1); log["dropped_rows"]+=int(miss.sum()); d=d[~miss]
        d["datetime"]=pd.to_datetime(d["datetime"]); dup=d.datetime.duplicated(); log["dropped_dupe_ts"]+=int(dup.sum()); d=d[~dup].sort_values("datetime")
        lab=d["anomaly"].fillna(0).astype(int) if "anomaly" in d else pd.Series(0,index=d.index)
        sid=f"SKAB_{rel}"
        out.append(pd.DataFrame(dict(machine_id="SKAB-PUMP",session_id=sid,timestamp=d.datetime.dt.strftime("%Y-%m-%d %H:%M:%S"),source="public",source_dataset="SKAB",fs_hz=1,
            temperature_value=d.Temperature.round(3),temperature_unit="C",current_mean_mA=(d.Current*1000).round(1),bus_voltage_V=d.Voltage.round(3),
            vib_rms_total=np.sqrt(d.Accelerometer1RMS**2+d.Accelerometer2RMS**2).round(5),fluid_temp_C=d.Thermocouple.round(3),pressure_bar=d.Pressure.round(4),
            flow_lpm=d["Volume Flow RateRMS"].round(3),label_binary=lab.values,fault_type=np.where(lab.values==1,"X","N"),split=split_of(sid))))
    df=pd.concat(out,ignore_index=True); df.insert(0,"record_id",[f"SKAB{i+1:06d}" for i in range(len(df))])
    os.makedirs(os.path.dirname(a.out) or ".",exist_ok=True); df.to_csv(a.out,index=False)
    log.update(rows=len(df),sessions=int(df.session_id.nunique()),by_split=df.split.value_counts().to_dict(),anomaly_rate=round(float(df.label_binary.mean()),3)); print(json.dumps(log,indent=1))
if __name__=="__main__": main()
