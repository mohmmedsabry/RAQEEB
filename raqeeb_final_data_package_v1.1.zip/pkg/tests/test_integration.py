"""Leave-one-source-out integration test on COMMON features only.  Purpose: MEASURE source gap & check transfer; NOT to train the final model.
python tests/test_integration.py --a data/data.csv --b staging/skab.csv --out validation/integration_report.json"""
import argparse, json, numpy as np, pandas as pd
from scipy.stats import wasserstein_distance as W
from sklearn.ensemble import IsolationForest
from sklearn.metrics import roc_auc_score, precision_score, recall_score
F=["temperature_value","current_mean_mA","vib_rms_total"]
ap=argparse.ArgumentParser(); ap.add_argument("--a",required=True); ap.add_argument("--b",required=True); ap.add_argument("--out"); a=ap.parse_args()
A=pd.read_csv(a.a); B=pd.read_csv(a.b); na,nb=A.source.iloc[0],B.source_dataset.iloc[0]
def norm_stats(d): n=d[(d.split=="train")&(d.label_binary==0)][F]; return n.mean(),n.std().replace(0,1)
sa,sb=norm_stats(A),norm_stats(B); z=lambda d,s:(d[F]-s[0])/s[1]
rep={"sources":{"A":f"RAQEEB({na})","B":nb},"common_features":F,"rows":{"A":len(A),"B":len(B)}}
# 1) distribution gap on NORMAL rows (Wasserstein): raw vs per-source z-score
nA=A[A.label_binary==0]; nB=B[B.label_binary==0]
rep["wasserstein_normal_rows"]={f:{"raw":round(float(W(nA[f],nB[f])),3),"after_per_source_zscore":round(float(W(z(nA,sa)[f],z(nB,sb)[f])),3)} for f in F}
def fit(d,s): return IsolationForest(n_estimators=200,random_state=0).fit(z(d[(d.split=="train")&(d.label_binary==0)],s))
def evaluate(model,d,s,thr_from=None):
    sc=lambda x:-model.score_samples(z(x,s)); te=d[d.split=="test"]; y=te.label_binary.values; p=sc(te)
    vn=d[(d.split=="val")&(d.label_binary==0)]; thr=np.quantile(sc(vn),0.95)       # threshold from the TARGET's own validation normal
    pr=(p>thr).astype(int); return dict(test_rows=len(te),AUC=round(float(roc_auc_score(y,p)),3),precision=round(float(precision_score(y,pr)),3),recall=round(float(recall_score(y,pr)),3),
        FPR=round(float(((pr==1)&(y==0)).sum()/max((y==0).sum(),1)),3))
mA,mB=fit(A,sa),fit(B,sb)
rep["within_source"]={"A->A":evaluate(mA,A,sa),"B->B":evaluate(mB,B,sb)}
rep["cross_source"]={"A->B (train RAQEEB, test SKAB)":evaluate(mA,B,sa if False else sb) ,"B->A (train SKAB, test RAQEEB)":evaluate(mB,A,sa)}
rep["note"]="كل مصدر يُطبَّع بإحصاءات الطبيعي الخاصة به. الـ threshold من validation المصدر الهدف. للقياس فقط - لا يدخل في تدريب الموديل النهائي."
print(json.dumps(rep,indent=1,ensure_ascii=False))
if a.out: json.dump(rep,open(a.out,"w"),indent=1,ensure_ascii=False)
