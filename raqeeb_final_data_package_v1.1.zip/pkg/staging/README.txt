staging/skab.csv غير مرفق (مشتق من SKAB بترخيص GPL-3.0). لإعادة توليده:
  git clone --depth 1 https://github.com/waico/SKAB ext/skab
  python adapters/skab_to_raqeeb.py --src ext/skab/data --out staging/skab.csv
