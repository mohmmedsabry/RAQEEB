"""RAQEEB - SIMULATED feature-level dataset generator.
Matches the planned schema (ESP32 + MPU6050 + INA219 + DS18B20 + GA25 encoder).
ALL values are SIMULATED (source=simulated). Replace with real bench recordings
using the same columns. Assumed constants are marked ASSUMED."""
import numpy as np, pandas as pd, os
rng = np.random.default_rng(2026)

SPEEDS = {"S1": (40, 120), "S2": (70, 220), "S3": (100, 320)}      # (pwm %, rpm)  ASSUMED
REGIMES = {"R1":("S1",0),"R2":("S1",1),"R3":("S2",0),"R4":("S2",1),"R5":("S3",0),"R6":("S3",1)}
TEETH = 15            # ASSUMED gear-mesh multiplier for dominant frequency
WIN_STEP_S = 5        # one 2-s window every 5 s
BANDS = ["band_0_50","band_50_150","band_150_250","band_250_500"]

def make_session(session_id, regime, fault, sev, n_win, start, ambient, mount, T0, fan_on):
    sp, load = REGIMES[regime]; pwm, rpm0 = SPEEDS[sp]
    rows = []
    # thermal model
    tss = ambient + 5 + 0.022*rpm0 + 2.5*load - (4 if fan_on else 0)
    tau = 420.0
    if fault == "F4": tss += 7*sev; tau = 600.0
    for i in range(n_win):
        t = i*WIN_STEP_S
        T = tss - (tss-T0)*np.exp(-t/tau) + rng.normal(0, 0.08)
        rpm = rpm0*(1-0.03*load) + rng.normal(0, 1.2)
        i_mean = 120 + 0.9*rpm0 + 90*load           # mA ASSUMED
        i_std = 18 + 6*load; i_max_k = 1.35
        rms_f = 1.0; crest = rng.normal(3.2,.22); kurt = rng.normal(3.0,.18); skew = rng.normal(0,.08)
        fr = np.array([.36,.34,.20,.10]) + np.array([-.04,0,.02,.02])*(rpm0-120)/200
        amp1x = abs(rng.normal(0.004,0.0005))*(rpm0/200)
        if fault == "F1":
            amp1x += 0.009*(1 if sev==1 else 2)*(rpm0/200)**2
            crest -= 0.25*sev; kurt -= 0.15*sev; fr += np.array([.05*sev,-.02*sev,-.02*sev,-.01*sev])
        if fault == "F2":
            rms_f += 0.14*sev; crest += 0.55*sev; kurt += 0.85*sev; skew += rng.normal(0,.15)
            fr += np.array([-.08*sev,-.02*sev,.04*sev,.06*sev])
        if fault == "F3":
            i_mean *= 1+0.33*sev; i_std *= 1+0.7*sev; i_max_k = 1.35+0.25*sev
            rpm *= 1-0.055*sev; rms_f += 0.07*sev; T += 0.6*sev*(1-np.exp(-t/tau))
        fr = np.clip(fr + rng.normal(0,0.012,4), 0.01, None); fr /= fr.sum()
        base = (0.030 + 0.00015*rpm0 + 0.005*load)*mount*rms_f
        axr = base*0.50*rng.normal(1,.04); ayr = base*0.30*rng.normal(1,.04); azr = base*0.40*rng.normal(1,.04)
        tot = np.sqrt(axr**2+ayr**2+azr**2 + (amp1x**2)/2)
        peak = tot*crest
        dom = TEETH*rpm/60 + rng.normal(0,0.6)
        cent = float(np.dot(fr, [25,100,200,350])) + rng.normal(0,4)
        volt = 11.85 - 0.0012*i_mean + rng.normal(0,.03)
        rows.append(dict(
            session_id=session_id, timestamp=(start+pd.Timedelta(seconds=t)).strftime("%Y-%m-%d %H:%M:%S"),
            temperature_value=round(T,2), rpm=round(rpm,1), pwm_duty=pwm,
            fan_state=0 if fault=="F4" else int(fan_on),
            current_mean_mA=round(i_mean*rng.normal(1,.015),1), current_std_mA=round(i_std*rng.normal(1,.05),1),
            current_max_mA=round(i_mean*i_max_k*rng.normal(1,.03),1), bus_voltage_V=round(volt,3),
            ax_rms=round(axr,5), ay_rms=round(ayr,5), az_rms=round(azr,5), vib_rms_total=round(tot,5),
            vib_peak=round(peak,5), vib_p2p=round(peak*rng.normal(1.9,.07),5), vib_crest=round(crest,3),
            vib_kurtosis=round(kurt,3), vib_skew=round(skew,3), dom_freq_hz=round(dom,2),
            spec_centroid_hz=round(cent,1), **{b:round(v,4) for b,v in zip(BANDS,fr)},
            amp_1x=round(amp1x,5), regime=regime, fault_type=fault if fault else "N", severity=sev))
    return rows

def build():
    sessions = []   # (id, regime, fault, sev, n_win, start, day_ambient, split, rep)
    allrows = []; log = []
    sid = 0
    day = {"A":("2026-11-10 09:00", 27.0), "B":("2026-11-10 14:00", 29.5), "C":("2026-11-14 10:00", 25.5)}
    mount_by_session = {}
    # normal: A train, B val, C test
    for tag, split in [("A","train"),("B","val"),("C","test")]:
        t0, amb = day[tag]; start = pd.Timestamp(t0)
        mount = rng.normal(1,0.05)
        for reg in REGIMES:
            sid += 1; s_id = f"S{sid:03d}_{reg}_N_{start.strftime('%Y%m%d')}_{tag}"
            fan_on = rng.random() < 0.5
            rows = make_session(s_id, reg, None, 0, 60, start, amb+rng.normal(0,.3), mount, amb+rng.uniform(1,4), fan_on)
            for r in rows: r["split"]=split
            allrows += rows
            log.append(dict(session_id=s_id, regime=reg, fault_type="N", severity=0, rep=tag, minutes=5, windows=60, split=split))
            start += pd.Timedelta(minutes=7)
    # abnormal: reps 1,2 -> val ; rep 3 -> test
    rep_day = {1:"2026-11-11 09:00", 2:"2026-11-11 15:00", 3:"2026-11-14 13:00"}
    for rep in (1,2,3):
        start = pd.Timestamp(rep_day[rep]); amb = {1:27.5,2:30.0,3:26.0}[rep]
        mount = rng.normal(1,0.05)
        for fault in ("F1","F2","F3","F4"):
            for sev in (1,2):
                for reg in ("R1","R5"):
                    sid += 1; s_id = f"S{sid:03d}_{reg}_{fault}-{sev}_{start.strftime('%Y%m%d')}_r{rep}"
                    n = 120 if fault=="F4" else 36
                    split = "test" if rep==3 else "val"
                    rows = make_session(s_id, reg, fault, sev, n, start, amb+rng.normal(0,.3), mount, amb+rng.uniform(1,3), False)
                    for r in rows: r["split"]=split
                    allrows += rows
                    log.append(dict(session_id=s_id, regime=reg, fault_type=fault, severity=sev, rep=f"r{rep}", minutes=n*WIN_STEP_S/60, windows=n, split=split))
                    start += pd.Timedelta(minutes=n*WIN_STEP_S/60+2)
    df = pd.DataFrame(allrows)
    df.insert(0,"record_id",[f"REC{i+1:06d}" for i in range(len(df))])
    df.insert(1,"machine_id","MOTOR-01"); df.insert(4,"sensor_id","DS18B20-01/MPU6050-01/INA219-01")
    df.insert(7,"temperature_unit","C")
    df["temp_slope_C_min"]=0.0
    for s,g in df.groupby("session_id"):
        T=g["temperature_value"].values; sl=np.zeros(len(T))
        for k in range(len(T)):
            j=max(0,k-12); sl[k]=(T[k]-T[j])/((k-j)*WIN_STEP_S/60) if k>=6 else 0.0
        df.loc[g.index,"temp_slope_C_min"]=np.round(sl,3)
    df["data_quality_status"]="ok"; df["source"]="simulated"
    df["label_binary"]=(df["fault_type"]!="N").astype(int)
    cols=["record_id","machine_id","session_id","timestamp","sensor_id","temperature_value","temperature_unit","temp_slope_C_min","rpm","pwm_duty","fan_state",
          "current_mean_mA","current_std_mA","current_max_mA","bus_voltage_V","ax_rms","ay_rms","az_rms","vib_rms_total","vib_peak","vib_p2p","vib_crest",
          "vib_kurtosis","vib_skew","dom_freq_hz","spec_centroid_hz"]+BANDS+["amp_1x","data_quality_status","source","label_binary","fault_type","severity","regime","split"]
    return df[cols], pd.DataFrame(log)

if __name__=="__main__":
    df, log = build()
    for sp in ("train","val","test"):
        d = {"train":"splits/train","val":"splits/val","test":"splits/LOCKED_TEST"}[sp]
        os.makedirs(d, exist_ok=True); df[df.split==sp].to_csv(f"{d}/{sp}_features.csv", index=False)
    os.makedirs("labels", exist_ok=True); log.to_csv("labels/session_log.csv", index=False)
    df.to_csv("features_all.csv", index=False)
    # data-quality test records (AT-001): invalid / stale / missing
    dq = df[df.split=="val"].sample(30, random_state=1).copy().reset_index(drop=True)
    dq["expected_status"]="valid"
    dq.loc[0:4,"temperature_value"]=-127.0; dq.loc[0:4,"expected_status"]="invalid_sensor_disconnected"
    dq.loc[5:9,"vib_rms_total"]=np.nan; dq.loc[5:9,"expected_status"]="invalid_missing_value"
    dq.loc[10:14,"timestamp"]="2026-11-01 00:00:00"; dq.loc[10:14,"expected_status"]="stale"
    dq.loc[15:17,"current_mean_mA"]=-50; dq.loc[15:17,"expected_status"]="invalid_out_of_range"
    os.makedirs("data_quality_tests", exist_ok=True); dq.to_csv("data_quality_tests/dq_test_records.csv", index=False)
    print(df.shape); print(df.groupby(["split","fault_type"]).size())
