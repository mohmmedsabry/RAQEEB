"""Baseline v0.2: Isolation Forest (normal-only training) + explicit thermal rule for F4.
Thresholds are tuned on VALIDATION only; LOCKED_TEST is evaluated once."""
import pandas as pd, numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, precision_score, recall_score
FEATS=["temperature_value","temp_slope_C_min","rpm","pwm_duty","current_mean_mA","current_std_mA","current_max_mA","bus_voltage_V","ax_rms","ay_rms","az_rms",
 "vib_rms_total","vib_peak","vib_p2p","vib_crest","vib_kurtosis","vib_skew","dom_freq_hz","spec_centroid_hz","band_0_50","band_50_150","band_150_250","band_250_500","amp_1x"]
D=pd.read_csv("data/data.csv"); tr,va,te=[D[D.split==k] for k in ("train","val","test")]   # split column from validated data.csv
tr=tr[tr.label_binary==0]
sc=StandardScaler().fit(tr[FEATS]); m=IsolationForest(n_estimators=300,random_state=0).fit(sc.transform(tr[FEATS]))
score=lambda d:-m.score_samples(sc.transform(d[FEATS]))
vn=va[va.label_binary==0]
thr=np.quantile(score(vn),0.97)                      # IF threshold
tmax=np.quantile(vn.temperature_value,0.995)         # thermal rule: absolute temperature
smax=np.quantile(vn.temp_slope_C_min,0.995)          # thermal rule: rise rate
print(f"IF thr={thr:.4f}  T_max={tmax:.2f}C  slope_max={smax:.2f}C/min  (all from validation normal)")
def pred(d, rule): 
    p=score(d)>thr
    return (p | (d.temperature_value>tmax) | (d.temp_slope_C_min>smax)).astype(int) if rule else p.astype(int)
for name,d in [("VALIDATION",va),("LOCKED TEST",te)]:
    for rule in (False,True):
        p=pred(d,rule); y=d.label_binary; tn,fp,fn,tp=confusion_matrix(y,p).ravel()
        print(f"\n{name} | {'IF + thermal rule' if rule else 'IF only'}: TN={tn} FP={fp} FN={fn} TP={tp} precision={precision_score(y,p):.3f} recall={recall_score(y,p):.3f}")
        print(d.assign(flag=p).groupby("fault_type").flag.mean().round(3).to_dict())
