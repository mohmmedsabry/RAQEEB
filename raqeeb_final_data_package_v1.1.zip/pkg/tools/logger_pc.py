"""PC-side logger. Reads the ESP32 window stream (serial or --replay file), saves RAW + features per window.
DRAFT: parser tested with a replay stream only; NOT tested with real hardware.
Protocol per window:  #WIN,<ms>,<pwm>,<fan>,<enc_pulses>,<temp_C>,<N>   then N lines  r,<ax>,<ay>,<az>,<shunt_raw|-1>,<bus_raw|-1>   then  #END
Also: '#TRIP,<reason>' = ESP32 cut the motor (log it)."""
import argparse, csv, os, sys, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_features import extract
ACC_LSB=8192.0       # MPU6050 +-4 g  (set in firmware)
SHUNT_OHM=0.1        # INA219 shunt  (ASSUMED module default - verify)
ENC_PPR_OUT=None     # TODO: encoder pulses per OUTPUT shaft revolution (from GA25 datasheet)
FS=1000
def parse_stream(lines):
    cur=None
    for ln in lines:
        ln=ln.strip()
        if ln.startswith("#WIN"):
            p=ln.split(","); cur=dict(ms=int(p[1]),pwm=int(p[2]),fan=int(p[3]),pulses=int(p[4]),temp=float(p[5]),n=int(p[6]),rows=[])
        elif ln.startswith("#TRIP"): yield {"trip":ln.split(",",1)[1] if "," in ln else "unknown"}
        elif ln.startswith("r,") and cur is not None: cur["rows"].append(ln.split(",")[1:])
        elif ln.startswith("#END") and cur is not None:
            if len(cur["rows"])==cur["n"]: yield cur
            else: yield {"bad_window":f"expected {cur['n']} got {len(cur['rows'])}"}
            cur=None
def to_features(w, window_s=2.0):
    a=np.array([[float(x) for x in r] for r in w["rows"]])
    ax,ay,az=a[:,0]/ACC_LSB,a[:,1]/ACC_LSB,a[:,2]/ACC_LSB
    sh=a[a[:,3]>=-0.5,3]; bus=a[a[:,4]>=-0.5,4]
    cur=np.abs(sh*0.01/SHUNT_OHM)            # shunt LSB=10 uV -> mA = raw*0.01mV/0.1ohm
    busV=bus*0.004*1.0                        # bus reg already >>3 in firmware; LSB 4 mV
    rpm=(w["pulses"]/ENC_PPR_OUT)/window_s*60 if ENC_PPR_OUT else float("nan")
    return extract(ax,ay,az,FS,rpm,w["temp"],cur,busV,w["pwm"],w["fan"])
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--port"); ap.add_argument("--baud",type=int,default=921600); ap.add_argument("--replay")
    for k in ("session","regime","fault","severity","split","out"): ap.add_argument("--"+k,required=(k in("session","regime","fault","split")),default={"severity":"0","out":"recordings"}.get(k))
    a=ap.parse_args(); os.makedirs(f"{a.out}/raw/{a.session}",exist_ok=True)
    src=open(a.replay) if a.replay else __import__("serial").Serial(a.port,a.baud,timeout=5)
    lines=(l if isinstance(l,str) else l.decode(errors="ignore") for l in iter(src.readline,"" if a.replay else b""))
    fp=f"{a.out}/features_{a.session}.csv"; new=not os.path.exists(fp); wi=0
    with open(fp,"a",newline="") as f:
        wr=None
        for w in parse_stream(lines):
            if "trip" in w: print("TRIP:",w["trip"]); continue
            if "bad_window" in w: print("BAD WINDOW:",w["bad_window"]); continue
            wi+=1; feat=to_features(w)
            meta=dict(record_id=f"{a.session}_W{wi:04d}",machine_id="MOTOR-01",session_id=a.session,timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
                      source="bench",data_quality_status="ok",label_binary=int(a.fault!="N"),fault_type=a.fault,severity=a.severity,regime=a.regime,split=a.split)
            row={**meta,**feat}
            with open(f"{a.out}/raw/{a.session}/win_{wi:04d}.csv","w") as rf: rf.write("ax,ay,az,shunt_raw,bus_raw\n"+"\n".join(",".join(r) for r in w["rows"]))
            if wr is None: wr=csv.DictWriter(f,fieldnames=list(row)); 
            if new and wi==1: wr.writeheader()
            wr.writerow(row); f.flush(); print("window",wi,"rms",feat["vib_rms_total"],"T",feat["temperature_value"])
if __name__=="__main__": main()
