"""v0.2 builder (SIMULATED). Fixes v0.1 gaps: faults at 3 speeds, balanced F4 (5 min), extra normal day + long warm-up
sessions, Workflow-3 before/after maintenance cases. Imports the v0.1 feature-level simulator."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
import generate_dataset as g
rng = g.rng; REG = g.REGIMES; STEP = g.WIN_STEP_S
def sess(sid, reg, fault, sev, n, start, amb, mount, fan):
    return g.make_session(sid, reg, fault, sev, n, start, amb+rng.normal(0,.3), mount, amb+rng.uniform(1,3.5), fan)
def build():
    rows, log, k = [], [], 0
    def add(r, split, fault, sev, rep, mins):
        for x in r: x["split"] = split
        rows.extend(r)
        log.append(dict(session_id=r[0]["session_id"], regime=r[0]["regime"], fault_type=fault, severity=sev, rep=rep, minutes=mins, windows=len(r), split=split))
    days = {"A":("2026-11-10 09:00",27.0,"train"),"B":("2026-11-10 14:00",29.5,"val"),"D":("2026-11-12 09:00",26.0,"train"),"C":("2026-11-14 10:00",25.5,"test")}
    for tag,(t0,amb,split) in days.items():
        st = pd.Timestamp(t0); m = rng.normal(1,.05)
        for reg in REG:
            k+=1; add(sess(f"S{k:03d}_{reg}_N_{st:%Y%m%d}_{tag}", reg, None, 0, 60, st, amb, m, rng.random()<.5), split, "N", 0, tag, 5); st += pd.Timedelta(minutes=7)
        if tag in ("A","C"):
            k+=1; add(sess(f"S{k:03d}_R3_Nlong_{st:%Y%m%d}_{tag}", "R3", None, 0, 240, st, amb, m, False), split, "N", 0, tag+"-long", 20)
    reps = {1:("2026-11-11 09:00",27.5,"val"),2:("2026-11-11 15:00",30.0,"val"),3:("2026-11-14 13:00",26.0,"test")}
    before = {}
    for rep,(t0,amb,split) in reps.items():
        st = pd.Timestamp(t0); m = rng.normal(1,.05)
        for f in ("F1","F2","F3","F4"):
            for sev in (1,2):
                for reg in ("R1","R3","R5"):
                    k+=1; n = 60 if f=="F4" else 36
                    r = sess(f"S{k:03d}_{reg}_{f}-{sev}_{st:%Y%m%d}_r{rep}", reg, f, sev, n, st, amb, m, False)
                    add(r, split, f, sev, f"r{rep}", n*STEP/60); st += pd.Timedelta(minutes=n*STEP/60+2)
                    if rep==2: before[(f,sev,reg)] = (r[0]["session_id"], r)
    df = pd.DataFrame(rows); df.insert(0,"record_id",[f"REC{i+1:06d}" for i in range(len(df))])
    df.insert(1,"machine_id","MOTOR-01"); df["sensor_id"]="DS18B20-01/MPU6050-01/INA219-01"; df["temperature_unit"]="C"
    def slope(T):
        s=np.zeros(len(T))
        for i in range(len(T)):
            j=max(0,i-12); s[i]=(T[i]-T[j])/((i-j)*STEP/60) if i>=6 else 0
        return np.round(s,3)
    df["temp_slope_C_min"]=np.concatenate([slope(x.temperature_value.values) for _,x in df.groupby("session_id",sort=False)])
    df["data_quality_status"]="ok"; df["source"]="simulated"; df["label_binary"]=(df.fault_type!="N").astype(int)
    cols=["record_id","machine_id","session_id","timestamp","sensor_id","temperature_value","temperature_unit","temp_slope_C_min","rpm","pwm_duty","fan_state",
     "current_mean_mA","current_std_mA","current_max_mA","bus_voltage_V","ax_rms","ay_rms","az_rms","vib_rms_total","vib_peak","vib_p2p","vib_crest",
     "vib_kurtosis","vib_skew","dom_freq_hz","spec_centroid_hz"]+g.BANDS+["amp_1x","data_quality_status","source","label_binary","fault_type","severity","regime","split"]
    df = df[cols]
    outcomes = ["fixed","fixed","not_fixed","partial"]*3
    cases, post_rows, ci = [], [], 0
    st = pd.Timestamp("2026-11-13 10:00"); m = rng.normal(1,.05)
    for f in ("F1","F2","F3"):
        for sev in (1,2):
            for reg in ("R1","R5"):
                sid_b, rb = before[(f,sev,reg)]; out = outcomes[ci]; ci+=1
                if out=="fixed": pf,ps=None,0
                elif out=="not_fixed": pf,ps=f,sev
                else:
                    if sev==1: pf,ps,out=None,0,"fixed"
                    else: pf,ps=f,1
                sid_p = f"PM{ci:02d}_{reg}_{'N' if pf is None else pf+'-'+str(ps)}_{st:%Y%m%d}"
                rp = sess(sid_p, reg, pf, ps, 24, st, 27.0, m, False); st += pd.Timedelta(minutes=6)
                for x in rp: x["split"]="workflow3"
                post_rows += rp
                b = pd.DataFrame(rb); p = pd.DataFrame(rp)
                cases.append(dict(case_id=f"CASE{ci:02d}", task_id=f"TASK{ci:02d}", machine_id="MOTOR-01", regime=reg, original_fault=f, original_severity=sev,
                  before_session_id=sid_b, post_session_id=sid_p, post_fault_state=("N" if pf is None else f"{pf}-{ps}"),
                  before_vib_rms=round(b.vib_rms_total.mean(),5), after_vib_rms=round(p.vib_rms_total.mean(),5),
                  vib_rms_change_pct=round(100*(p.vib_rms_total.mean()/b.vib_rms_total.mean()-1),1),
                  before_kurtosis=round(b.vib_kurtosis.mean(),3), after_kurtosis=round(p.vib_kurtosis.mean(),3),
                  before_current_mA=round(b.current_mean_mA.mean(),1), after_current_mA=round(p.current_mean_mA.mean(),1),
                  expected_outcome={"fixed":"close","not_fixed":"reopen","partial":"escalate_or_review"}[out]))
    post = pd.DataFrame(post_rows); post.insert(0,"record_id",[f"PMREC{i+1:05d}" for i in range(len(post))]); post.insert(1,"machine_id","MOTOR-01")
    post["source"]="simulated"; post["data_quality_status"]="ok"
    return df, pd.DataFrame(log), pd.DataFrame(cases), post
if __name__=="__main__":
    df,log,cases,post = build()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
    for sp,d in [("train","splits/train"),("val","splits/val"),("test","splits/LOCKED_TEST")]:
        df[df.split==sp].to_csv(f"{out}/{d}/{sp}_features.csv", index=False)
    log.to_csv(f"{out}/labels/session_log_simulated.csv", index=False)
    cases.to_csv(f"{out}/workflow3/maintenance_cases.csv", index=False); post.to_csv(f"{out}/workflow3/post_maintenance_features.csv", index=False)
    dq = df[df.split=="val"].sample(40, random_state=1).reset_index(drop=True); dq["expected_status"]="valid"
    dq.loc[0:4,"temperature_value"]=-127.0; dq.loc[0:4,"expected_status"]="invalid_sensor_disconnected"
    dq.loc[5:9,"vib_rms_total"]=np.nan; dq.loc[5:9,"expected_status"]="invalid_missing_value"
    dq.loc[10:14,"timestamp"]="2026-11-01 00:00:00"; dq.loc[10:14,"expected_status"]="stale"
    dq.loc[15:17,"current_mean_mA"]=-50; dq.loc[15:17,"expected_status"]="invalid_out_of_range"
    dq.loc[18:20,"rpm"]=-1; dq.loc[18:20,"expected_status"]="invalid_out_of_range"
    dq.to_csv(f"{out}/data_quality_tests/dq_test_records.csv", index=False)
    print(df.groupby(["split","fault_type"]).size().unstack(fill_value=0)); print(cases[["case_id","original_fault","original_severity","post_fault_state","vib_rms_change_pct","expected_outcome"]].to_string(index=False))
